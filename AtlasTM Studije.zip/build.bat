@echo off
setlocal enabledelayedexpansion

if not exist out (
    echo Prvo pokreni compile.bat
    pause
    exit /b 1
)

:: Nadji jar.exe automatski
set JAR_EXE=

:: Pokusaj direktno (ako je u PATH)
where jar >nul 2>&1
if not errorlevel 1 (
    set JAR_EXE=jar
    goto :found
)

:: Trazi kroz JAVA_HOME
if defined JAVA_HOME (
    if exist "%JAVA_HOME%\bin\jar.exe" (
        set JAR_EXE="%JAVA_HOME%\bin\jar.exe"
        goto :found
    )
)

:: Trazi kroz javac lokaciju
for /f "delims=" %%i in ('where javac 2^>nul') do (
    set JAVAC_PATH=%%i
    set JAR_EXE="!JAVAC_PATH:javac.exe=jar.exe!"
    if exist !JAR_EXE! goto :found
)

:: Rucna pretraga u Program Files\Java
for /d %%d in ("C:\Program Files\Java\jdk*") do (
    if exist "%%d\bin\jar.exe" (
        set JAR_EXE="%%d\bin\jar.exe"
        goto :found
    )
)
for /d %%d in ("C:\Program Files\Java\latest") do (
    if exist "%%d\bin\jar.exe" (
        set JAR_EXE="%%d\bin\jar.exe"
        goto :found
    )
)

echo GRESKA: Nije pronasao jar.exe. Proveri da li je JDK instaliran.
pause
exit /b 1

:found
echo Koristim: !JAR_EXE!

if not exist out\META-INF mkdir out\META-INF
echo Main-Class: atlas.studije.Main > out\META-INF\MANIFEST.MF
cd out
!JAR_EXE! cfm ..\AtlasTMStudije.jar META-INF\MANIFEST.MF .
cd ..
echo JAR napravljen: AtlasTMStudije.jar
echo Dvoklik na pokretanje.bat pokrece aplikaciju.
pause
