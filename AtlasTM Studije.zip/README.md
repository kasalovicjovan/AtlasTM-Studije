<div align="center">

<img src="atlas/studije/Logo.png" alt="AtlasTM Studije Logo" width="110"/>

<h1>AtlasTM — Studije</h1>

<p>A desktop application for university students to track subjects, grades, ECTS credits, tasks, and academic obligations — all stored locally on your computer.</p>

<p>
  <img src="https://img.shields.io/badge/Java-8%2B-ED8B00?style=flat-square&logo=openjdk&logoColor=white"/>
  <img src="https://img.shields.io/badge/UI-Java%20Swing-5C8EBF?style=flat-square"/>
  <img src="https://img.shields.io/badge/Platform-Windows-0078D4?style=flat-square&logo=windows&logoColor=white"/>
  <img src="https://img.shields.io/badge/Storage-Local%20JSON-6DB33F?style=flat-square"/>
  <img src="https://img.shields.io/badge/License-MIT-brightgreen?style=flat-square"/>
</p>

</div>

---

## About

**AtlasTM — Studije** is a personal academic management tool built from scratch in Java Swing. It runs entirely offline — no cloud, no external accounts. Your data stays on your machine in a simple JSON file.

Designed for students who want one clean place to manage everything related to their university life.

---

## Features

### Subject Tracking
- Add subjects with name, year, semester, ECTS credits, grade, and status
- Three statuses: **In Progress**, **Passed**, **Failed**
- Per-subject point breakdown — log individual scoring categories (e.g. midterm, final, homework) and track total points earned
- Add notes per subject

### Task & Obligation Management
- Create tasks with a title, description, and due date
- Mark tasks as completed
- Collapsible task panel with slide/fade animation

### User Accounts
- Local multi-user support with login and registration
- Passwords are hashed with **SHA-256** — never stored in plain text
- User data is fully isolated per account

### Custom Interface
- Custom dark theme with gold accents, built entirely with Java Swing
- Responsive split-pane layout with animated panels
- Navigation bar: Subjects, Tasks, Semesters, Profile, Settings

### Data Storage
- All data saved automatically to `%APPDATA%\AtlasStudije\data.json`
- No database setup required — works out of the box

---

## Screenshots

> *(Add screenshots here — drag images into the repo and link them below)*

```
![Login Screen](docs/screenshots/login.png)
![Main Dashboard](docs/screenshots/main.png)
![Subject Detail](docs/screenshots/subject.png)
```

---

## Requirements

| Requirement | Details |
|---|---|
| Java (JDK) | Version 8 or higher |
| Operating System | Windows (primary support) |

> **No Java installed?** The launcher (`pokretanje.bat`) will automatically download a portable Java runtime (~180MB, Temurin JRE 21) on first run. Nothing else needed.

---

## Getting Started

### Option 1 — Download and run (recommended)

1. Download the latest release from the [Releases](../../releases) page
2. Extract the ZIP
3. Double-click **`pokretanje.bat`**

The launcher detects your Java installation automatically. If Java isn't found, it downloads a portable runtime and launches the app.

### Option 2 — Build from source

**1. Clone the repository**
```bash
git clone https://github.com/YOUR_USERNAME/atlasTM-studije.git
cd atlasTM-studije
```

**2. Compile**
```
compile.bat
```
Compiles all source files with Java 8 compatibility and copies the logo into the output directory.

**3. Package into a JAR**
```
build.bat
```
Produces `AtlasTMStudije.jar` in the project root.

**4. Run**
```
pokretanje.bat
```

---

## Project Structure

```
AtlasTM_Studije/
├── atlas/
│   └── studije/
│       ├── Main.java               # Entry point — initializes theme, DB, and login screen
│       ├── DataManager.java        # Singleton — all data read/write operations (JSON)
│       ├── model/
│       │   ├── User.java           # User model
│       │   ├── Subject.java        # Subject model with PointEntry inner class
│       │   ├── SubjectStatus.java  # Enum: IN_PROGRESS, PASSED, FAILED
│       │   └── Task.java           # Task/obligation model
│       ├── ui/
│       │   ├── LoginFrame.java     # Login and registration screen
│       │   ├── MainFrame.java      # Main application window
│       │   ├── SubjectDialog.java  # Add/edit subject dialog
│       │   └── TaskDialog.java     # Add/edit task dialog
│       ├── util/
│       │   └── Theme.java          # Full custom dark theme — colors, fonts, component styling
│       └── Logo.png                # Application logo
├── compile.bat                     # Compiles all sources to out/
├── build.bat                       # Packages out/ into AtlasTMStudije.jar
└── pokretanje.bat                  # Smart launcher with auto JRE download fallback
```

---

## Data & Privacy

- All data stored **locally** at `%APPDATA%\AtlasStudije\data.json`
- Passwords stored as **SHA-256 hashes** — never in plain text
- No network requests are made (except when `pokretanje.bat` downloads the JRE if Java is missing)
- To uninstall: delete the app folder and `%APPDATA%\AtlasStudije\`

---

## License

This project is licensed under the **MIT License**.

```
MIT License

Copyright (c) 2025 TM

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

---

<div align="center">
  <sub>Built with Java Swing · Made by TM</sub>
</div>
