@echo off
if not exist out mkdir out
javac -encoding UTF-8 -source 8 -target 8 -d out atlas\studije\util\Theme.java atlas\studije\model\*.java atlas\studije\DataManager.java atlas\studije\ui\*.java atlas\studije\Main.java
if errorlevel 1 (
    echo Greska pri kompilaciji!
    pause
    exit /b 1
)
if exist "atlas\studije\Logo.png" copy /Y "atlas\studije\Logo.png" "out\atlas\studije\Logo.png" >nul 2>&1
if exist "atlas\studije\Logo.jpg" copy /Y "atlas\studije\Logo.jpg" "out\atlas\studije\Logo.jpg" >nul 2>&1
echo Kompilacija zavrsena.
pause
