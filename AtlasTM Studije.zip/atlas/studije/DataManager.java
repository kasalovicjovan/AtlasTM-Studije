package atlas.studije;

import atlas.studije.model.Subject;
import atlas.studije.model.SubjectStatus;
import atlas.studije.model.Task;
import atlas.studije.model.User;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class DataManager {
    private static final String DB_DIRECTORY = (System.getenv("APPDATA") != null ? System.getenv("APPDATA") : System.getProperty("user.home")) + "\\AtlasStudije";
    private static final String DB_PATH = DB_DIRECTORY + "\\data.json";

    private static final DataManager INSTANCE = new DataManager();

    private final List<StoredUser> users;
    private final List<Subject> subjects;
    private final List<Task> tasks;
    private boolean initialized;

    private DataManager() {
        this.users = new ArrayList<StoredUser>();
        this.subjects = new ArrayList<Subject>();
        this.tasks = new ArrayList<Task>();
        this.initialized = false;
    }

    public static DataManager getInstance() {
        return INSTANCE;
    }

    public synchronized boolean initialize() {
        if (initialized) {
            return true;
        }
        try {
            Path directory = normalizedPath(DB_DIRECTORY);
            Files.createDirectories(directory);
            Path dataPath = normalizedPath(DB_PATH);
            if (!Files.exists(dataPath)) {
                clearData();
                if (!saveData()) {
                    return false;
                }
            } else {
                String content = new String(Files.readAllBytes(dataPath), StandardCharsets.UTF_8).trim();
                if (content.isEmpty()) {
                    clearData();
                    if (!saveData()) {
                        return false;
                    }
                } else {
                    loadFromJson(content);
                }
            }
            initialized = true;
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public synchronized boolean registerUser(String username, String password) {
        String safeUsername = normalizeUsername(username);
        String safePassword = password == null ? "" : password;
        if (safeUsername.length() < 3 || safePassword.length() < 4 || usernameExists(safeUsername)) {
            return false;
        }
        StoredUser user = new StoredUser();
        user.id = nextUserId();
        user.username = safeUsername;
        user.passwordHash = sha256(safePassword);
        users.add(user);
        return saveData();
    }

    public synchronized boolean loginUser(String username, String password, User outUser) {
        String safeUsername = normalizeUsername(username);
        String safePassword = password == null ? "" : password;
        String hash = sha256(safePassword);
        for (StoredUser user : users) {
            if (user.username.equalsIgnoreCase(safeUsername) && user.passwordHash.equals(hash)) {
                if (outUser != null) {
                    outUser.setId(user.id);
                    outUser.setUsername(user.username);
                }
                return true;
            }
        }
        return false;
    }

    public synchronized boolean usernameExists(String username) {
        String safeUsername = normalizeUsername(username);
        for (StoredUser user : users) {
            if (user.username.equalsIgnoreCase(safeUsername)) {
                return true;
            }
        }
        return false;
    }

    public synchronized boolean changePassword(int userId, String newPassword) {
        if (newPassword == null || newPassword.length() < 4) {
            return false;
        }
        for (StoredUser user : users) {
            if (user.id == userId) {
                user.passwordHash = sha256(newPassword);
                return saveData();
            }
        }
        return false;
    }

    public synchronized List<Subject> getSubjects(int userId) {
        List<Subject> result = new ArrayList<Subject>();
        for (Subject subject : subjects) {
            if (subject.getUserId() == userId) {
                result.add(subject.copy());
            }
        }
        Collections.sort(result, new Comparator<Subject>() {
            @Override
            public int compare(Subject o1, Subject o2) {
                int byYear = Integer.compare(o1.getYear(), o2.getYear());
                if (byYear != 0) {
                    return byYear;
                }
                int bySemester = Integer.compare(o1.getSemester(), o2.getSemester());
                if (bySemester != 0) {
                    return bySemester;
                }
                return o1.getName().compareToIgnoreCase(o2.getName());
            }
        });
        return result;
    }

    public synchronized boolean addSubject(Subject subject) {
        if (subject == null) {
            return false;
        }
        Subject copy = subject.copy();
        copy.setId(nextSubjectId());
        subject.setId(copy.getId());
        subjects.add(copy);
        return saveData();
    }

    public synchronized boolean updateSubject(Subject subject) {
        if (subject == null) {
            return false;
        }
        for (int i = 0; i < subjects.size(); i++) {
            if (subjects.get(i).getId() == subject.getId()) {
                subjects.set(i, subject.copy());
                return saveData();
            }
        }
        return false;
    }

    public synchronized boolean deleteSubject(int subjectId) {
        for (int i = 0; i < subjects.size(); i++) {
            if (subjects.get(i).getId() == subjectId) {
                subjects.remove(i);
                return saveData();
            }
        }
        return false;
    }

    public synchronized List<Task> getTasks(int userId) {
        List<Task> result = new ArrayList<Task>();
        for (Task task : tasks) {
            if (task.getUserId() == userId) {
                result.add(task.copy());
            }
        }
        Collections.sort(result, new Comparator<Task>() {
            @Override
            public int compare(Task o1, Task o2) {
                int byDate = o1.getDate().compareTo(o2.getDate());
                if (byDate != 0) {
                    return byDate;
                }
                return o1.getTitle().compareToIgnoreCase(o2.getTitle());
            }
        });
        return result;
    }

    public synchronized boolean addTask(Task task) {
        if (task == null) {
            return false;
        }
        Task copy = task.copy();
        copy.setId(nextTaskId());
        task.setId(copy.getId());
        tasks.add(copy);
        return saveData();
    }

    public synchronized boolean updateTask(Task task) {
        if (task == null) {
            return false;
        }
        for (int i = 0; i < tasks.size(); i++) {
            if (tasks.get(i).getId() == task.getId()) {
                tasks.set(i, task.copy());
                return saveData();
            }
        }
        return false;
    }

    public synchronized boolean deleteTask(int taskId) {
        for (int i = 0; i < tasks.size(); i++) {
            if (tasks.get(i).getId() == taskId) {
                tasks.remove(i);
                return saveData();
            }
        }
        return false;
    }

    public synchronized String getDatabaseDirectory() {
        return normalizedPath(DB_DIRECTORY).toString();
    }

    private void clearData() {
        users.clear();
        subjects.clear();
        tasks.clear();
    }

    private void loadFromJson(String json) {
        clearData();
        Object parsed = new JsonParser(json).parse();
        if (!(parsed instanceof Map)) {
            return;
        }
        Map<?, ?> root = (Map<?, ?>) parsed;
        Object usersValue = root.get("users");
        if (usersValue instanceof List) {
            List<?> userList = (List<?>) usersValue;
            for (Object entry : userList) {
                if (entry instanceof Map) {
                    Map<?, ?> map = (Map<?, ?>) entry;
                    StoredUser user = new StoredUser();
                    user.id = getInt(map.get("id"), 0);
                    user.username = getString(map.get("username"));
                    user.passwordHash = getString(map.get("passwordHash"));
                    if (!user.username.isEmpty()) {
                        users.add(user);
                    }
                }
            }
        }

        Object subjectsValue = root.get("subjects");
        if (subjectsValue instanceof List) {
            List<?> subjectList = (List<?>) subjectsValue;
            for (Object entry : subjectList) {
                if (entry instanceof Map) {
                    Map<?, ?> map = (Map<?, ?>) entry;
                    Subject subject = new Subject();
                    subject.setId(getInt(map.get("id"), 0));
                    subject.setUserId(getInt(map.get("userId"), 0));
                    subject.setName(getString(map.get("name")));
                    subject.setSemester(getInt(map.get("semester"), 1));
                    subject.setYear(getInt(map.get("year"), 1));
                    subject.setEcts(getInt(map.get("ects"), 0));
                    subject.setGrade(getDouble(map.get("grade"), 0.0));
                    subject.setStatus(SubjectStatus.fromCode(getInt(map.get("status"), 1)));
                    subject.setNotes(getString(map.get("notes")));
                    List<Subject.PointEntry> pointEntries = new ArrayList<Subject.PointEntry>();
                    Object pointsValue = map.get("points");
                    if (pointsValue instanceof List) {
                        List<?> pointsList = (List<?>) pointsValue;
                        for (Object pointEntry : pointsList) {
                            if (pointEntry instanceof Map) {
                                Map<?, ?> pointMap = (Map<?, ?>) pointEntry;
                                pointEntries.add(new Subject.PointEntry(getString(pointMap.get("desc")), getDouble(pointMap.get("pts"), 0.0)));
                            }
                        }
                    }
                    subject.setPointEntries(pointEntries);
                    if (!subject.getName().isEmpty()) {
                        subjects.add(subject);
                    }
                }
            }
        }

        Object tasksValue = root.get("tasks");
        if (tasksValue instanceof List) {
            List<?> taskList = (List<?>) tasksValue;
            for (Object entry : taskList) {
                if (entry instanceof Map) {
                    Map<?, ?> map = (Map<?, ?>) entry;
                    Task task = new Task();
                    task.setId(getInt(map.get("id"), 0));
                    task.setUserId(getInt(map.get("userId"), 0));
                    task.setTitle(getString(map.get("title")));
                    task.setDescription(getString(map.get("description")));
                    task.setDate(parseDate(getString(map.get("date"))));
                    task.setCompleted(getBoolean(map.get("completed"), false));
                    if (!task.getTitle().isEmpty()) {
                        tasks.add(task);
                    }
                }
            }
        }
    }

    private boolean saveData() {
        Map<String, Object> root = new LinkedHashMap<String, Object>();
        List<Object> usersOut = new ArrayList<Object>();
        for (StoredUser user : users) {
            Map<String, Object> map = new LinkedHashMap<String, Object>();
            map.put("id", user.id);
            map.put("username", user.username);
            map.put("passwordHash", user.passwordHash);
            usersOut.add(map);
        }
        List<Object> subjectsOut = new ArrayList<Object>();
        for (Subject subject : subjects) {
            Map<String, Object> map = new LinkedHashMap<String, Object>();
            map.put("id", subject.getId());
            map.put("userId", subject.getUserId());
            map.put("name", subject.getName());
            map.put("semester", subject.getSemester());
            map.put("year", subject.getYear());
            map.put("ects", subject.getEcts());
            map.put("grade", subject.getGrade());
            map.put("status", subject.getStatus() == null ? SubjectStatus.IN_PROGRESS.getCode() : subject.getStatus().getCode());
            map.put("notes", subject.getNotes());
            List<Object> pointList = new ArrayList<Object>();
            for (Subject.PointEntry entry : subject.getPointEntries()) {
                Map<String, Object> pointMap = new LinkedHashMap<String, Object>();
                pointMap.put("desc", entry.getDescription());
                pointMap.put("pts", entry.getPoints());
                pointList.add(pointMap);
            }
            map.put("points", pointList);
            subjectsOut.add(map);
        }
        List<Object> tasksOut = new ArrayList<Object>();
        for (Task task : tasks) {
            Map<String, Object> map = new LinkedHashMap<String, Object>();
            map.put("id", task.getId());
            map.put("userId", task.getUserId());
            map.put("title", task.getTitle());
            map.put("description", task.getDescription());
            map.put("date", task.getDate() == null ? LocalDate.now().toString() : task.getDate().toString());
            map.put("completed", task.isCompleted());
            tasksOut.add(map);
        }
        root.put("users", usersOut);
        root.put("subjects", subjectsOut);
        root.put("tasks", tasksOut);

        Path path = normalizedPath(DB_PATH);
        try {
            Files.createDirectories(path.getParent());
            Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);
            bufferedWriter.write(JsonWriter.write(root));
            bufferedWriter.flush();
            bufferedWriter.close();
            return true;
        } catch (IOException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    private int nextUserId() {
        int max = 0;
        for (StoredUser user : users) {
            if (user.id > max) {
                max = user.id;
            }
        }
        return max + 1;
    }

    private int nextSubjectId() {
        int max = 0;
        for (Subject subject : subjects) {
            if (subject.getId() > max) {
                max = subject.getId();
            }
        }
        return max + 1;
    }

    private int nextTaskId() {
        int max = 0;
        for (Task task : tasks) {
            if (task.getId() > max) {
                max = task.getId();
            }
        }
        return max + 1;
    }

    private static String normalizeUsername(String username) {
        return username == null ? "" : username.trim();
    }

    private static LocalDate parseDate(String value) {
        try {
            return value == null || value.trim().isEmpty() ? LocalDate.now() : LocalDate.parse(value.trim());
        } catch (Exception ex) {
            return LocalDate.now();
        }
    }

    private static int getInt(Object value, int defaultValue) {
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        try {
            return value == null ? defaultValue : Integer.parseInt(String.valueOf(value));
        } catch (Exception ex) {
            return defaultValue;
        }
    }

    private static double getDouble(Object value, double defaultValue) {
        if (value instanceof Number) {
            return ((Number) value).doubleValue();
        }
        try {
            return value == null ? defaultValue : Double.parseDouble(String.valueOf(value));
        } catch (Exception ex) {
            return defaultValue;
        }
    }

    private static boolean getBoolean(Object value, boolean defaultValue) {
        if (value instanceof Boolean) {
            return ((Boolean) value).booleanValue();
        }
        if (value == null) {
            return defaultValue;
        }
        return Boolean.parseBoolean(String.valueOf(value));
    }

    private static String getString(Object value) {
        return value == null ? "" : String.valueOf(value);
    }

    private static String sha256(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest((input == null ? "" : input).getBytes(StandardCharsets.UTF_8));
            StringBuilder builder = new StringBuilder();
            for (byte b : hash) {
                builder.append(String.format(Locale.US, "%02x", b));
            }
            return builder.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 није доступан.", e);
        }
    }

    private static Path normalizedPath(String value) {
        String normalized = value.replace("\\", java.io.File.separator);
        return Paths.get(normalized);
    }

    private static class StoredUser {
        private int id;
        private String username;
        private String passwordHash;
    }

    private static class JsonWriter {
        private JsonWriter() {
        }

        public static String write(Object value) {
            StringBuilder sb = new StringBuilder();
            writeValue(sb, value, 0);
            return sb.toString();
        }

        private static void writeValue(StringBuilder sb, Object value, int indent) {
            if (value == null) {
                sb.append("null");
            } else if (value instanceof Map) {
                writeObject(sb, (Map<?, ?>) value, indent);
            } else if (value instanceof List) {
                writeArray(sb, (List<?>) value, indent);
            } else if (value instanceof String) {
                sb.append('"').append(escape((String) value)).append('"');
            } else if (value instanceof Number) {
                if (value instanceof Double || value instanceof Float) {
                    double d = ((Number) value).doubleValue();
                    if (Math.floor(d) == d) {
                        sb.append(String.format(Locale.US, "%.1f", d));
                    } else {
                        sb.append(String.format(Locale.US, "%s", trimDouble(d)));
                    }
                } else {
                    sb.append(String.valueOf(value));
                }
            } else if (value instanceof Boolean) {
                sb.append(((Boolean) value).booleanValue() ? "true" : "false");
            } else {
                sb.append('"').append(escape(String.valueOf(value))).append('"');
            }
        }

        private static void writeObject(StringBuilder sb, Map<?, ?> map, int indent) {
            sb.append("{\n");
            int index = 0;
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                appendIndent(sb, indent + 2);
                sb.append('"').append(escape(String.valueOf(entry.getKey()))).append('"').append(": ");
                writeValue(sb, entry.getValue(), indent + 2);
                if (index < map.size() - 1) {
                    sb.append(',');
                }
                sb.append('\n');
                index++;
            }
            appendIndent(sb, indent);
            sb.append('}');
        }

        private static void writeArray(StringBuilder sb, List<?> list, int indent) {
            sb.append('[');
            if (!list.isEmpty()) {
                sb.append('\n');
                for (int i = 0; i < list.size(); i++) {
                    appendIndent(sb, indent + 2);
                    writeValue(sb, list.get(i), indent + 2);
                    if (i < list.size() - 1) {
                        sb.append(',');
                    }
                    sb.append('\n');
                }
                appendIndent(sb, indent);
            }
            sb.append(']');
        }

        private static void appendIndent(StringBuilder sb, int indent) {
            for (int i = 0; i < indent; i++) {
                sb.append(' ');
            }
        }

        private static String trimDouble(double value) {
            String text = String.format(Locale.US, "%.10f", value);
            while (text.contains(".") && (text.endsWith("0") || text.endsWith("."))) {
                if (text.endsWith(".")) {
                    return text + "0";
                }
                text = text.substring(0, text.length() - 1);
            }
            return text;
        }

        private static String escape(String value) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < value.length(); i++) {
                char c = value.charAt(i);
                switch (c) {
                    case '\\': sb.append("\\\\"); break;
                    case '"': sb.append("\\\""); break;
                    case '\n': sb.append("\\n"); break;
                    case '\r': sb.append("\\r"); break;
                    case '\t': sb.append("\\t"); break;
                    case '\b': sb.append("\\b"); break;
                    case '\f': sb.append("\\f"); break;
                    default:
                        if (c < 32) {
                            sb.append(String.format(Locale.US, "\\u%04x", (int) c));
                        } else {
                            sb.append(c);
                        }
                }
            }
            return sb.toString();
        }
    }

    private static class JsonParser {
        private final String text;
        private int index;

        private JsonParser(String text) {
            this.text = text == null ? "" : text;
            this.index = 0;
        }

        public Object parse() {
            skipWhitespace();
            Object value = parseValue();
            skipWhitespace();
            return value;
        }

        private Object parseValue() {
            skipWhitespace();
            if (index >= text.length()) {
                return null;
            }
            char c = text.charAt(index);
            if (c == '{') {
                return parseObject();
            }
            if (c == '[') {
                return parseArray();
            }
            if (c == '"') {
                return parseString();
            }
            if (c == 't' || c == 'f') {
                return parseBoolean();
            }
            if (c == 'n') {
                return parseNull();
            }
            return parseNumber();
        }

        private Map<String, Object> parseObject() {
            Map<String, Object> map = new LinkedHashMap<String, Object>();
            index++;
            skipWhitespace();
            if (index < text.length() && text.charAt(index) == '}') {
                index++;
                return map;
            }
            while (index < text.length()) {
                skipWhitespace();
                String key = parseString();
                skipWhitespace();
                if (index < text.length() && text.charAt(index) == ':') {
                    index++;
                }
                Object value = parseValue();
                map.put(key, value);
                skipWhitespace();
                if (index < text.length() && text.charAt(index) == ',') {
                    index++;
                    continue;
                }
                if (index < text.length() && text.charAt(index) == '}') {
                    index++;
                    break;
                }
            }
            return map;
        }

        private List<Object> parseArray() {
            List<Object> list = new ArrayList<Object>();
            index++;
            skipWhitespace();
            if (index < text.length() && text.charAt(index) == ']') {
                index++;
                return list;
            }
            while (index < text.length()) {
                Object value = parseValue();
                list.add(value);
                skipWhitespace();
                if (index < text.length() && text.charAt(index) == ',') {
                    index++;
                    continue;
                }
                if (index < text.length() && text.charAt(index) == ']') {
                    index++;
                    break;
                }
            }
            return list;
        }

        private String parseString() {
            StringBuilder sb = new StringBuilder();
            if (index < text.length() && text.charAt(index) == '"') {
                index++;
            }
            while (index < text.length()) {
                char c = text.charAt(index++);
                if (c == '"') {
                    break;
                }
                if (c == '\\' && index < text.length()) {
                    char next = text.charAt(index++);
                    switch (next) {
                        case '"': sb.append('"'); break;
                        case '\\': sb.append('\\'); break;
                        case '/': sb.append('/'); break;
                        case 'b': sb.append('\b'); break;
                        case 'f': sb.append('\f'); break;
                        case 'n': sb.append('\n'); break;
                        case 'r': sb.append('\r'); break;
                        case 't': sb.append('\t'); break;
                        case 'u':
                            if (index + 3 < text.length()) {
                                String hex = text.substring(index, index + 4);
                                try {
                                    sb.append((char) Integer.parseInt(hex, 16));
                                } catch (NumberFormatException ignored) {
                                }
                                index += 4;
                            }
                            break;
                        default: sb.append(next);
                    }
                } else {
                    sb.append(c);
                }
            }
            return sb.toString();
        }

        private Object parseNumber() {
            int start = index;
            while (index < text.length()) {
                char c = text.charAt(index);
                if ((c >= '0' && c <= '9') || c == '-' || c == '+' || c == '.' || c == 'e' || c == 'E') {
                    index++;
                } else {
                    break;
                }
            }
            String number = text.substring(start, index).trim();
            if (number.isEmpty()) {
                return 0;
            }
            try {
                if (number.contains(".") || number.contains("e") || number.contains("E")) {
                    return Double.parseDouble(number);
                }
                long value = Long.parseLong(number);
                if (value <= Integer.MAX_VALUE && value >= Integer.MIN_VALUE) {
                    return (int) value;
                }
                return value;
            } catch (NumberFormatException ex) {
                return 0;
            }
        }

        private Boolean parseBoolean() {
            if (text.startsWith("true", index)) {
                index += 4;
                return Boolean.TRUE;
            }
            if (text.startsWith("false", index)) {
                index += 5;
                return Boolean.FALSE;
            }
            return Boolean.FALSE;
        }

        private Object parseNull() {
            if (text.startsWith("null", index)) {
                index += 4;
            }
            return null;
        }

        private void skipWhitespace() {
            while (index < text.length()) {
                char c = text.charAt(index);
                if (c == ' ' || c == '\n' || c == '\r' || c == '\t') {
                    index++;
                } else {
                    break;
                }
            }
        }
    }
}
