package atlas.studije;

import atlas.studije.ui.LoginFrame;
import atlas.studije.util.Theme;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import java.awt.BasicStroke;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;

public class Main {
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
        }

        Theme.installDefaults();

        if (!DataManager.getInstance().initialize()) {
            JOptionPane.showMessageDialog(null,
                    "База података није доступна. Апликација не може да се покрене.",
                    "Грешка",
                    JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        saveIconToDataDirectory();

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                LoginFrame frame = new LoginFrame();
                Image icon = loadLogo();
                if (icon != null) {
                    frame.setIconImage(icon);
                }
                frame.setVisible(true);
            }
        });
    }

    public static Image loadLogo() {
        Image image = loadLogoFromClasspath();
        if (image != null) {
            return image;
        }
        image = loadLogoFromDirectory(resolveApplicationDirectory());
        if (image != null) {
            return image;
        }
        image = loadLogoFromDirectory(new File(System.getProperty("user.dir", ".")));
        if (image != null) {
            return image;
        }
        return generateFallbackIcon();
    }

    public static BufferedImage generateFallbackIcon() {
        int size = 64;
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(Theme.BG_CARD2);
        g.fillRoundRect(0, 0, size, size, 16, 16);
        g.setColor(Theme.GOLD);
        g.setStroke(new BasicStroke(2));
        g.drawRoundRect(1, 1, size - 2, size - 2, 16, 16);
        g.setColor(Theme.GOLD);
        g.setFont(new Font("Segoe UI", Font.BOLD, 36));
        FontMetrics fm = g.getFontMetrics();
        String letter = "A";
        int x = (size - fm.stringWidth(letter)) / 2;
        int y = (size - fm.getHeight()) / 2 + fm.getAscent();
        g.drawString(letter, x, y);
        g.dispose();
        return img;
    }

    public static javax.swing.ImageIcon scaledLogoIcon(int size) {
        Image image = loadLogo();
        if (image == null) {
            return null;
        }
        BufferedImage result = progressiveScale(image, size);
        return new javax.swing.ImageIcon(result);
    }

    private static BufferedImage progressiveScale(Image source, int target) {
        BufferedImage img;
        if (source instanceof BufferedImage) {
            img = (BufferedImage) source;
        } else {
            img = new BufferedImage(
                    source.getWidth(null), source.getHeight(null),
                    BufferedImage.TYPE_INT_ARGB
            );
            Graphics2D g0 = img.createGraphics();
            g0.drawImage(source, 0, 0, null);
            g0.dispose();
        }

        int w = img.getWidth();
        int h = img.getHeight();

        while (w > target * 2 && h > target * 2) {
            w = Math.max(w / 2, target);
            h = Math.max(h / 2, target);
            BufferedImage step = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = step.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                    RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g.setRenderingHint(RenderingHints.KEY_RENDERING,
                    RenderingHints.VALUE_RENDER_QUALITY);
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            g.drawImage(img, 0, 0, w, h, null);
            g.dispose();
            img = step;
        }

        BufferedImage finalImage = new BufferedImage(target, target, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = finalImage.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING,
                RenderingHints.VALUE_RENDER_QUALITY);
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);
        g2.drawImage(img, 0, 0, target, target, null);
        g2.dispose();

        return finalImage;
    }


    private static Image loadLogoFromClasspath() {
        java.io.InputStream is = null;
        try {
            is = Main.class.getResourceAsStream("/atlas/studije/Logo.png");
            if (is != null) {
                return ImageIO.read(is);
            }
        } catch (IOException ignored) {
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException ignored) {
                }
            }
        }
        return null;
    }


    private static Image loadLogoFromDirectory(File directory) {
        if (directory == null || !directory.exists()) {
            return null;
        }
        File png = new File(directory, "Logo.png");
        if (png.exists()) {
            try {
                return ImageIO.read(png);
            } catch (IOException ignored) {
            }
        }
        File jpg = new File(directory, "Logo.jpg");
        if (jpg.exists()) {
            try {
                return ImageIO.read(jpg);
            } catch (IOException ignored) {
            }
        }
        return null;
    }

    private static File resolveApplicationDirectory() {
        try {
            File location = new File(Main.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            if (location.isFile()) {
                return location.getParentFile();
            }
            return location;
        } catch (URISyntaxException ignored) {
            return new File(System.getProperty("user.dir", "."));
        }
    }

    private static void saveIconToDataDirectory() {
        try {
            Image image = loadLogo();
            if (image == null) {
                return;
            }
            BufferedImage bufferedImage;
            if (image instanceof BufferedImage) {
                bufferedImage = (BufferedImage) image;
            } else {
                bufferedImage = new BufferedImage(image.getWidth(null), image.getHeight(null), BufferedImage.TYPE_INT_ARGB);
                Graphics2D g2 = bufferedImage.createGraphics();
                g2.drawImage(image, 0, 0, null);
                g2.dispose();
            }
            File file = new File(DataManager.getInstance().getDatabaseDirectory(), "icon.png");
            if (!file.exists()) {
                ImageIO.write(bufferedImage, "PNG", file);
            }
        } catch (Exception ignored) {
        }
    }
}
