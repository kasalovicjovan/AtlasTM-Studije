package atlas.studije.util;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.Icon;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListCellRenderer;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.AbstractBorder;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.TitledBorder;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicArrowButton;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.plaf.basic.BasicSpinnerUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.text.JTextComponent;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.Paint;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.awt.Window;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.awt.geom.RoundRectangle2D;
import java.io.IOException;
import java.io.InputStream;

public final class Theme {
    public static final Color BG_DEEP = new Color(0x07, 0x0B, 0x12);
    public static final Color BG_CARD = new Color(0x0A, 0x10, 0x1C);
    public static final Color BG_CARD2 = new Color(0x11, 0x1C, 0x2D);
    public static final Color SURFACE = new Color(0x0E, 0x16, 0x24);

    public static final Color BORDER = new Color(128, 183, 255, 46);
    public static final Color BORDER_FOCUS = new Color(89, 167, 255, 85);

    public static final Color TEXT = new Color(0xEA, 0xF4, 0xFF);
    public static final Color MUTED = new Color(0x93, 0xA6, 0xC3);

    public static final Color BLUE = new Color(0x59, 0xA7, 0xFF);
    public static final Color BLUE_2 = new Color(0x90, 0xD7, 0xFF);
    public static final Color GOLD = new Color(0xD9, 0xB1, 0x5C);
    public static final Color GOLD_2 = new Color(0xF7, 0xD8, 0x96);

    public static final Color SUCCESS = new Color(0x8F, 0xF6, 0xC8);
    public static final Color DANGER = new Color(0xFF, 0x8E, 0x9A);
    public static final Color DANGER_DARK = new Color(0xC0, 0x50, 0x4A);

    public static final Color ACCENT = GOLD;
    public static final Color ACCENT_2 = GOLD_2;
    public static final Color ACCENT_HOVER = GOLD_2;
    public static final Color DANGER_FILL = new Color(192, 80, 74, 38);

    private static final String[] FALLBACK_FONTS = new String[] {"Segoe UI", "SF Pro Text", "Dialog"};
    private static Font primaryFontPlain;
    private static Font primaryFontBold;
    private static Font brandFontBold;

    static {
        installSpinnerUIDefaults();
    }

    private Theme() {
    }

    public static void installDefaults() {
        installSpinnerUIDefaults();
        UIManager.put("ToolTip.background", BG_CARD2);
        UIManager.put("ToolTip.foreground", TEXT);
        UIManager.put("ToolTip.border", BorderFactory.createLineBorder(BORDER));
        UIManager.put("ToolTip.font", fontPlain(12));
        UIManager.put("ComboBox.selectionBackground", BLUE);
        UIManager.put("ComboBox.selectionForeground", BG_DEEP);
        UIManager.put("List.selectionBackground", SURFACE);
        UIManager.put("List.selectionForeground", TEXT);
    }

    public static Font fontPlain(int size) {
        ensureFonts();
        return primaryFontPlain.deriveFont((float) size);
    }

    public static Font fontBold(int size) {
        ensureFonts();
        return primaryFontBold.deriveFont((float) size);
    }

    public static Font brandFont(int size) {
        ensureFonts();
        return brandFontBold.deriveFont((float) size);
    }

    private static void ensureFonts() {
        if (primaryFontPlain != null && primaryFontBold != null && brandFontBold != null) {
            return;
        }
        Font loadedPrimary = loadFontFromResource("/atlas/studije/SpaceGrotesk-Regular.ttf", Font.PLAIN);
        Font loadedPrimaryBold = loadFontFromResource("/atlas/studije/SpaceGrotesk-Bold.ttf", Font.BOLD);
        Font loadedBrand = loadFontFromResource("/atlas/studije/Orbitron-Bold.ttf", Font.BOLD);

        if (loadedPrimary == null) {
            loadedPrimary = fallbackFont(Font.PLAIN);
        }
        if (loadedPrimaryBold == null) {
            loadedPrimaryBold = fallbackFont(Font.BOLD);
        }
        if (loadedBrand == null) {
            loadedBrand = loadedPrimaryBold;
        }
        primaryFontPlain = loadedPrimary;
        primaryFontBold = loadedPrimaryBold;
        brandFontBold = loadedBrand;
    }

    private static Font fallbackFont(int style) {
        int i;
        for (i = 0; i < FALLBACK_FONTS.length; i++) {
            Font font = new Font(FALLBACK_FONTS[i], style, 13);
            if (font != null) {
                return font;
            }
        }
        return new Font("Dialog", style, 13);
    }

    private static Font loadFontFromResource(String path, int style) {
        InputStream inputStream = null;
        try {
            inputStream = Theme.class.getResourceAsStream(path);
            if (inputStream == null) {
                return null;
            }
            Font font = Font.createFont(Font.TRUETYPE_FONT, inputStream);
            return font.deriveFont(style, 13f);
        } catch (IOException ignored) {
            return null;
        } catch (FontFormatException ignored) {
            return null;
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException ignored) {
                }
            }
        }
    }

    public static void applyWindow(Window window) {
        if (window != null) {
            window.setBackground(BG_DEEP);
        }
    }

    public static JButton primaryButton(String text) {
        return createButton(text, ButtonStyle.PRIMARY);
    }

    public static JButton secondaryButton(String text) {
        return createButton(text, ButtonStyle.SECONDARY);
    }

    public static JButton dangerButton(String text) {
        return createButton(text, ButtonStyle.DANGER);
    }

    public static JButton navButton(String text) {
        return createButton(text, ButtonStyle.NAV);
    }



    public static Icon settingsIcon(final int size, final Color color) {
        return new Icon() {
            @Override
            public void paintIcon(Component c, Graphics g, int x, int y) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.translate(x, y);
                g2.setColor(color);
                g2.setStroke(new BasicStroke(Math.max(1.6f, size / 7.5f), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

                int cx = size / 2;
                int cy = size / 2;
                int outer = Math.max(2, size / 2 - 3);
                int inner = Math.max(2, size / 5);

                for (int i = 0; i < 8; i++) {
                    double a = i * Math.PI / 4.0;
                    int x1 = cx + (int) Math.round(Math.cos(a) * (outer - 2));
                    int y1 = cy + (int) Math.round(Math.sin(a) * (outer - 2));
                    int x2 = cx + (int) Math.round(Math.cos(a) * outer);
                    int y2 = cy + (int) Math.round(Math.sin(a) * outer);
                    g2.drawLine(x1, y1, x2, y2);
                }

                g2.drawOval(cx - inner, cy - inner, inner * 2, inner * 2);
                g2.dispose();
            }

            @Override
            public int getIconWidth() {
                return size;
            }

            @Override
            public int getIconHeight() {
                return size;
            }
        };
    }

    public static Icon logoutIcon(final int size, final Color color) {
        return new Icon() {
            @Override
            public void paintIcon(Component c, Graphics g, int x, int y) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.translate(x, y);
                g2.setColor(color);
                g2.setStroke(new BasicStroke(Math.max(1.7f, size / 8.0f), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

                int pad = Math.max(2, size / 7);
                int doorW = Math.max(5, size / 3);
                int doorH = Math.max(8, size - pad * 2);
                int doorX = pad;
                int doorY = pad;
                g2.drawRoundRect(doorX, doorY, doorW, doorH, 3, 3);

                int startX = doorX + doorW + 1;
                int midY = size / 2;
                int endX = size - pad - 1;
                g2.drawLine(startX, midY, endX - 4, midY);
                g2.drawLine(endX - 7, midY - 4, endX - 1, midY);
                g2.drawLine(endX - 7, midY + 4, endX - 1, midY);

                g2.dispose();
            }

            @Override
            public int getIconWidth() {
                return size;
            }

            @Override
            public int getIconHeight() {
                return size;
            }
        };
    }

    public static Icon trashIcon(final int width, final int height, final Color color) {
        return new Icon() {
            @Override
            public void paintIcon(Component c, Graphics g, int x, int y) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.translate(x, y);
                g2.setColor(color);
                g2.setStroke(new BasicStroke(Math.max(1.6f, Math.min(width, height) / 10.0f), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

                int lidY = Math.max(2, height / 4);
                int left = Math.max(3, width / 4);
                int right = width - left;
                int top = lidY + 2;
                int bottom = height - 3;

                g2.drawLine(left - 1, lidY, right + 1, lidY);
                g2.drawLine(width / 2 - 3, lidY - 2, width / 2 + 3, lidY - 2);
                g2.drawRoundRect(left, top, right - left, bottom - top, 3, 3);
                int x1 = width / 2 - 3;
                int x2 = width / 2;
                int x3 = width / 2 + 3;
                g2.drawLine(x1, top + 2, x1, bottom - 2);
                g2.drawLine(x2, top + 2, x2, bottom - 2);
                g2.drawLine(x3, top + 2, x3, bottom - 2);
                g2.dispose();
            }

            @Override
            public int getIconWidth() {
                return width;
            }

            @Override
            public int getIconHeight() {
                return height;
            }
        };
    }

    public static JButton roundAccentButton(String text) {
        ThemedButton button = new ThemedButton(text, ButtonStyle.ROUND_ACCENT);
        button.setPreferredSize(new Dimension(34, 34));
        button.setMinimumSize(new Dimension(34, 34));
        button.setMaximumSize(new Dimension(34, 34));
        button.setFont(fontBold(18));
        button.setForeground(BG_DEEP);
        button.setMargin(new Insets(0, 0, 0, 0));
        return button;
    }

    private static JButton createButton(String text, ButtonStyle style) {
        ThemedButton button = new ThemedButton(text, style);
        button.setOpaque(false);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setFont(style == ButtonStyle.NAV ? fontBold(12) : fontBold(13));
        if (style == ButtonStyle.NAV) {
            button.setForeground(MUTED);
            button.setMargin(new Insets(8, 12, 8, 12));
        } else {
            button.setMargin(new Insets(8, 12, 8, 12));
        }
        return button;
    }

    public static JTextField inputField() {
        return inputField("");
    }

    public static JTextField inputField(String prompt) {
        PromptTextField field = new PromptTextField(prompt == null ? "" : prompt);
        styleTextComponent(field);
        return field;
    }

    public static JPasswordField passwordField() {
        return passwordField("");
    }

    public static JPasswordField passwordField(String prompt) {
        PromptPasswordField field = new PromptPasswordField(prompt == null ? "" : prompt);
        styleTextComponent(field);
        return field;
    }

    public static JTextArea textArea(int rows) {
        return textArea(rows, "");
    }

    public static JTextArea textArea(int rows, String prompt) {
        PromptTextArea area = new PromptTextArea(prompt == null ? "" : prompt);
        area.setRows(rows);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        styleTextComponent(area);
        area.setBorder(compoundFieldBorder(BORDER, 10, 9, 12));
        return area;
    }

    private static void styleTextComponent(final JTextComponent component) {
        component.setOpaque(true);
        component.setBackground(BG_CARD);
        component.setForeground(TEXT);
        component.setCaretColor(TEXT);
        component.setSelectionColor(BLUE);
        component.setSelectedTextColor(BG_DEEP);
        component.setFont(fontPlain(13));
        component.setBorder(compoundFieldBorder(BORDER, 10, 9, 12));
        component.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                component.setBorder(compoundFieldBorder(BORDER_FOCUS, 10, 9, 12));
                component.repaint();
            }

            @Override
            public void focusLost(FocusEvent e) {
                component.setBorder(compoundFieldBorder(BORDER, 10, 9, 12));
                component.repaint();
            }
        });
    }

    public static CompoundBorder compoundFieldBorder(Color color, int radius, int vPad, int hPad) {
        return BorderFactory.createCompoundBorder(new RoundedBorder(color, 1, radius), BorderFactory.createEmptyBorder(vPad, hPad, vPad, hPad));
    }

    private static void installSpinnerUIDefaults() {
        UIManager.put("Spinner.background", BG_CARD);
        UIManager.put("Spinner.foreground", TEXT);
        UIManager.put("TextField.background", BG_CARD);
        UIManager.put("TextField.foreground", TEXT);
    }

    private static void applySpinnerEditorColors(final JSpinner spinner) {
        applySpinnerEditorColorsNow(spinner);
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                applySpinnerEditorColorsNow(spinner);
            }
        });
    }

    private static void applySpinnerEditorColorsNow(JSpinner spinner) {
        if (spinner == null) {
            return;
        }
        spinner.setBackground(BG_CARD);
        spinner.setForeground(TEXT);
        if (spinner.getEditor() instanceof JSpinner.DefaultEditor) {
            JSpinner.DefaultEditor editor = (JSpinner.DefaultEditor) spinner.getEditor();
            JTextField field = editor.getTextField();
            field.setBackground(BG_CARD);
            field.setForeground(TEXT);
            field.setCaretColor(TEXT);
            field.setOpaque(true);
            field.setFont(fontPlain(13));
        }
        tintSpinnerChildren(spinner);
        spinner.repaint();
    }

    private static void tintSpinnerChildren(Component component) {
        if (component == null) {
            return;
        }
        component.setBackground(BG_CARD);
        component.setForeground(TEXT);
        if (component instanceof java.awt.Container) {
            Component[] children = ((java.awt.Container) component).getComponents();
            int i;
            for (i = 0; i < children.length; i++) {
                tintSpinnerChildren(children[i]);
            }
        }
    }

    public static JPanel card() {
        return card(null);
    }

    public static JPanel card(LayoutManager layout) {
        RoundedPanel panel = layout == null ? new RoundedPanel() : new RoundedPanel(layout);
        panel.setBackground(new Color(10, 16, 28, 214));
        panel.setRadius(14);
        panel.setBorder(BorderFactory.createCompoundBorder(new RoundedBorder(BORDER, 1, 14), BorderFactory.createEmptyBorder(12, 12, 12, 12)));
        return panel;
    }

    public static JPanel elevatedCard() {
        RoundedPanel panel = new RoundedPanel();
        panel.setBackground(new Color(17, 28, 45, 224));
        panel.setRadius(14);
        panel.setBorder(BorderFactory.createCompoundBorder(new RoundedBorder(BORDER, 1, 14), BorderFactory.createEmptyBorder(12, 12, 12, 12)));
        return panel;
    }

    public static JPanel surfaceCard() {
        return surfaceCard(null);
    }

    public static JPanel surfaceCard(LayoutManager layout) {
        RoundedPanel panel = layout == null ? new RoundedPanel() : new RoundedPanel(layout);
        panel.setBackground(new Color(17, 28, 45, 224));
        panel.setRadius(14);
        panel.setBorder(BorderFactory.createCompoundBorder(new RoundedBorder(BORDER, 1, 14), BorderFactory.createEmptyBorder(12, 12, 12, 12)));
        return panel;
    }

    public static JLabel mutedLabel(String text) {
        JLabel label = new JLabel(text == null ? "" : text);
        label.setForeground(MUTED);
        label.setFont(fontPlain(12));
        return label;
    }

    public static JLabel sectionTitle(String text) {
        JLabel label = new JLabel(text == null ? "" : text);
        label.setForeground(TEXT);
        label.setFont(fontBold(14));
        label.setBorder(BorderFactory.createEmptyBorder(16, 0, 10, 0));
        return label;
    }

    public static JLabel errorLabel() {
        JLabel label = new JLabel(" ");
        label.setForeground(DANGER);
        label.setFont(fontPlain(12));
        label.setVisible(false);
        return label;
    }

    public static TitledBorder titledBorder(String title) {
        TitledBorder border = BorderFactory.createTitledBorder(new RoundedBorder(BORDER, 1, 10), title);
        border.setTitleColor(TEXT);
        border.setTitleFont(fontBold(13));
        return border;
    }

    public static void applyScrollPane(JScrollPane scrollPane) {
        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.getViewport().setBackground(new Color(0, 0, 0, 0));
        scrollPane.setBackground(new Color(0, 0, 0, 0));
        styleScrollBar(scrollPane.getVerticalScrollBar());
        styleScrollBar(scrollPane.getHorizontalScrollBar());
    }

    private static void styleScrollBar(JScrollBar scrollBar) {
        if (scrollBar == null) {
            return;
        }
        scrollBar.setOpaque(false);
        scrollBar.setUnitIncrement(16);
        scrollBar.setUI(new BasicScrollBarUI() {
            @Override
            protected void configureScrollBarColors() {
                thumbColor = BORDER;
                trackColor = new Color(0, 0, 0, 0);
            }

            @Override
            protected JButton createDecreaseButton(int orientation) {
                return createZeroButton();
            }

            @Override
            protected JButton createIncreaseButton(int orientation) {
                return createZeroButton();
            }

            @Override
            protected void paintTrack(Graphics g, JComponent c, Rectangle trackBounds) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(new Color(0, 0, 0, 0));
                g2.fillRect(trackBounds.x, trackBounds.y, trackBounds.width, trackBounds.height);
                g2.dispose();
            }

            @Override
            protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
                if (thumbBounds.isEmpty() || !scrollbar.isEnabled()) {
                    return;
                }
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BORDER);
                int arc = isDragging ? 10 : 8;
                if (scrollbar.getOrientation() == JScrollBar.VERTICAL) {
                    g2.fillRoundRect(thumbBounds.x + 3, thumbBounds.y + 2, Math.max(6, thumbBounds.width - 6), Math.max(16, thumbBounds.height - 4), arc, arc);
                } else {
                    g2.fillRoundRect(thumbBounds.x + 2, thumbBounds.y + 3, Math.max(16, thumbBounds.width - 4), Math.max(6, thumbBounds.height - 6), arc, arc);
                }
                g2.dispose();
            }
        });
    }

    private static JButton createZeroButton() {
        JButton button = new JButton();
        button.setPreferredSize(new Dimension(0, 0));
        button.setMinimumSize(new Dimension(0, 0));
        button.setMaximumSize(new Dimension(0, 0));
        return button;
    }

    public static <T> void applyList(JList<T> list) {
        list.setOpaque(false);
        list.setBackground(new Color(0, 0, 0, 0));
        list.setForeground(TEXT);
        list.setSelectionBackground(SURFACE);
        list.setSelectionForeground(TEXT);
        list.setFont(fontPlain(13));
        list.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        list.setFixedCellHeight(68);
    }

    public static void applyTable(JTable table) {
        table.setBackground(BG_CARD);
        table.setForeground(TEXT);
        table.setGridColor(BORDER);
        table.setSelectionBackground(BLUE);
        table.setSelectionForeground(BG_DEEP);
        table.setFont(fontPlain(13));
        table.setRowHeight(36);
        table.setIntercellSpacing(new Dimension(1, 1));
        table.setShowGrid(true);
        table.setFillsViewportHeight(true);
        JTableHeader header = table.getTableHeader();
        header.setBackground(BG_CARD2);
        header.setForeground(MUTED);
        header.setFont(fontPlain(12));
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER));
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setOpaque(true);
        renderer.setBackground(BG_CARD);
        renderer.setForeground(TEXT);
        renderer.setFont(fontPlain(13));
        table.setDefaultRenderer(Object.class, renderer);
    }

    public static void applyComboBox(final JComboBox<?> comboBox) {
        comboBox.setOpaque(false);
        comboBox.setBackground(BG_CARD);
        comboBox.setForeground(TEXT);
        comboBox.setFont(fontPlain(13));
        comboBox.setBorder(compoundFieldBorder(BORDER, 10, 8, 12));
        comboBox.setFocusable(true);
        comboBox.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                comboBox.setBorder(compoundFieldBorder(BORDER_FOCUS, 10, 8, 12));
            }

            @Override
            public void focusLost(FocusEvent e) {
                comboBox.setBorder(compoundFieldBorder(BORDER, 10, 8, 12));
            }
        });
        comboBox.setUI(new AtlasComboBoxUI());
        comboBox.setRenderer(new ListCellRenderer<Object>() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                JLabel label = new JLabel(value == null ? "" : String.valueOf(value));
                label.setFont(fontPlain(13));
                label.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
                label.setOpaque(true);
                if (index >= 0) {
                    label.setBackground(isSelected ? BG_CARD2 : BG_CARD);
                    label.setForeground(TEXT);
                } else {
                    label.setBackground(BG_CARD);
                    label.setForeground(TEXT);
                }
                return label;
            }
        });
    }

    public static void applySpinner(JSpinner spinner) {
        installSpinnerUIDefaults();
        spinner.setFont(fontPlain(13));
        spinner.setOpaque(true);
        spinner.setBackground(BG_CARD);
        spinner.setForeground(TEXT);
        spinner.setBorder(BorderFactory.createEmptyBorder(2, 8, 2, 0));
        spinner.setUI(new AtlasSpinnerUI());
        if (spinner.getEditor() instanceof JSpinner.DefaultEditor) {
            JSpinner.DefaultEditor editor = (JSpinner.DefaultEditor) spinner.getEditor();
            JTextField field = editor.getTextField();
            field.setOpaque(true);
            field.setBackground(BG_CARD);
            field.setForeground(TEXT);
            field.setCaretColor(TEXT);
            field.setFont(fontPlain(13));
            field.setBorder(BorderFactory.createEmptyBorder(0, 6, 0, 2));
        }
        applySpinnerEditorColors(spinner);
    }

    public static JPanel styledSpinnerWrapper(final JSpinner spinner) {
        installSpinnerUIDefaults();
        spinner.setBorder(BorderFactory.createEmptyBorder(2, 8, 2, 0));
        spinner.setOpaque(false);
        spinner.setBackground(BG_CARD);
        spinner.setForeground(TEXT);
        spinner.setFont(fontPlain(13));
        spinner.setUI(new AtlasSpinnerUI());

        if (spinner.getEditor() instanceof JSpinner.DefaultEditor) {
            JSpinner.DefaultEditor editor = (JSpinner.DefaultEditor) spinner.getEditor();
            JTextField field = editor.getTextField();
            field.setOpaque(true);
            field.setBackground(BG_CARD);
            field.setForeground(TEXT);
            field.setCaretColor(TEXT);
            field.setFont(fontPlain(13));
            field.setBorder(BorderFactory.createEmptyBorder(0, 6, 0, 2));
            field.setHorizontalAlignment(JTextField.RIGHT);
        }
        applySpinnerEditorColors(spinner);

        final boolean[] focused = {false};

        JPanel wrapper = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BG_CARD);
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
                g2.setColor(focused[0] ? BORDER_FOCUS : BORDER);
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
                g2.dispose();
            }
        };
        wrapper.setOpaque(false);
        wrapper.add(spinner, BorderLayout.CENTER);

        Component editorComp;
        if (spinner.getEditor() instanceof JSpinner.DefaultEditor) {
            editorComp = ((JSpinner.DefaultEditor) spinner.getEditor()).getTextField();
        } else {
            editorComp = spinner.getEditor();
        }
        editorComp.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                focused[0] = true;
                wrapper.repaint();
            }

            @Override
            public void focusLost(FocusEvent e) {
                focused[0] = false;
                wrapper.repaint();
            }
        });

        return wrapper;
    }

    public static void styleCheckBox(JCheckBox checkBox) {
        checkBox.setOpaque(false);
        checkBox.setForeground(TEXT);
        checkBox.setFont(fontPlain(13));
        checkBox.setFocusPainted(false);
    }

    public static class BackgroundPanel extends JPanel {
        private final boolean fillBase;
        private final int gridSize;

        public BackgroundPanel() {
            this(null, true, 48);
        }

        public BackgroundPanel(LayoutManager layout) {
            this(layout, true, 48);
        }

        public BackgroundPanel(LayoutManager layout, boolean fillBase, int gridSize) {
            super(layout);
            this.fillBase = fillBase;
            this.gridSize = gridSize <= 0 ? 48 : gridSize;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

            int w = getWidth();
            int h = getHeight();

            if (fillBase) {
                GradientPaint base = new GradientPaint(
                        0, 0, new Color(0x05, 0x07, 0x0C),
                        0, h, new Color(0x06, 0x0A, 0x11)
                );
                g2.setPaint(base);
                g2.fillRect(0, 0, w, h);
            }

            RadialGradientPaint blue1 = new RadialGradientPaint(
                    new Point2D.Float(w * 0.20f, h * 0.20f),
                    Math.max(120f, w * 0.28f),
                    new float[] {0f, 1f},
                    new Color[] {new Color(89, 167, 255, 46), new Color(0, 0, 0, 0)}
            );
            g2.setPaint(blue1);
            g2.fillRect(0, 0, w, h);

            RadialGradientPaint gold = new RadialGradientPaint(
                    new Point2D.Float(w * 0.80f, h * 0.02f),
                    Math.max(100f, w * 0.22f),
                    new float[] {0f, 1f},
                    new Color[] {new Color(217, 177, 92, 30), new Color(0, 0, 0, 0)}
            );
            g2.setPaint(gold);
            g2.fillRect(0, 0, w, h);

            RadialGradientPaint blue2 = new RadialGradientPaint(
                    new Point2D.Float(w * 0.90f, h * 0.90f),
                    Math.max(100f, w * 0.26f),
                    new float[] {0f, 1f},
                    new Color[] {new Color(89, 167, 255, 25), new Color(0, 0, 0, 0)}
            );
            g2.setPaint(blue2);
            g2.fillRect(0, 0, w, h);

            g2.setColor(new Color(255, 255, 255, 5));
            g2.setStroke(new BasicStroke(1f));
            int x;
            for (x = 0; x < w; x += gridSize) {
                g2.drawLine(x, 0, x, h);
            }
            int y;
            for (y = 0; y < h; y += gridSize) {
                g2.drawLine(0, y, w, y);
            }

            g2.dispose();
            super.paintComponent(g);
        }
    }

    public static class RoundedPanel extends JPanel {
        private int radius = 14;
        private boolean shadow = true;

        public RoundedPanel() {
            super();
            setOpaque(false);
        }

        public RoundedPanel(LayoutManager layout) {
            super(layout);
            setOpaque(false);
        }

        public void setRadius(int radius) {
            this.radius = radius;
        }

        public void setShadow(boolean shadow) {
            this.shadow = shadow;
        }

        @Override
        protected void paintComponent(Graphics g) {
            setOpaque(false);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            if (shadow) {
                g2.setColor(new Color(0, 0, 0, 60));
                g2.fillRoundRect(0, 8, getWidth(), Math.max(0, getHeight() - 8), radius, radius);
            }
            g2.setColor(getBackground());
            g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), radius, radius));
            g2.dispose();
            super.paintComponent(g);
        }
    }

    public static class RoundedBorder extends AbstractBorder {
        private final Color color;
        private final int thickness;
        private final int radius;

        public RoundedBorder(Color color, int thickness, int radius) {
            this.color = color;
            this.thickness = thickness;
            this.radius = radius;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.setStroke(new BasicStroke(thickness));
            g2.drawRoundRect(x, y, width - 1, height - 1, radius, radius);
            g2.dispose();
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(thickness + 1, thickness + 1, thickness + 1, thickness + 1);
        }

        @Override
        public Insets getBorderInsets(Component c, Insets insets) {
            insets.left = thickness + 1;
            insets.right = thickness + 1;
            insets.top = thickness + 1;
            insets.bottom = thickness + 1;
            return insets;
        }
    }

    private enum ButtonStyle {
        PRIMARY, SECONDARY, DANGER, NAV, ROUND_ACCENT
    }

    private static class ThemedButton extends JButton {
        private final ButtonStyle style;
        private boolean hovered;

        private ThemedButton(String text, ButtonStyle style) {
            super(text);
            this.style = style;
            setHorizontalAlignment(SwingConstants.CENTER);
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    hovered = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hovered = false;
                    repaint();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            boolean active = hovered || getModel().isPressed();
            if (style == ButtonStyle.PRIMARY) {
                GradientPaint gp = new GradientPaint(0, 0, active ? brighten(GOLD_2, 10) : GOLD_2, w, 0, active ? brighten(BLUE_2, 10) : BLUE_2);
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, w - 1, h - 1, 10, 10);
                setForeground(new Color(0x08, 0x10, 0x18));
            } else if (style == ButtonStyle.SECONDARY) {
                g2.setColor(active ? new Color(255, 255, 255, 20) : new Color(255, 255, 255, 10));
                g2.fillRoundRect(0, 0, w - 1, h - 1, 10, 10);
                g2.setColor(active ? new Color(255, 255, 255, 34) : new Color(255, 255, 255, 20));
                g2.drawRoundRect(0, 0, w - 1, h - 1, 10, 10);
                setForeground(TEXT);
            } else if (style == ButtonStyle.DANGER) {
                if (active) {
                    g2.setColor(DANGER_FILL);
                    g2.fillRoundRect(0, 0, w - 1, h - 1, 10, 10);
                }
                g2.setColor(BORDER);
                g2.drawRoundRect(0, 0, w - 1, h - 1, 10, 10);
                setForeground(active ? DANGER : DANGER_DARK);
            } else if (style == ButtonStyle.ROUND_ACCENT) {
                g2.setColor(active ? GOLD_2 : GOLD);
                g2.fillOval(0, 0, w - 1, h - 1);
                setForeground(BG_DEEP);
            } else {
                if (active) {
                    g2.setColor(new Color(255, 255, 255, 13));
                    g2.fillRoundRect(0, 0, w - 1, h - 1, 8, 8);
                }
                Object base = getClientProperty("navBaseForeground");
                setForeground(active ? TEXT : (base instanceof Color ? (Color) base : MUTED));
            }
            g2.dispose();
            super.paintComponent(g);
        }
    }

    private static Color brighten(Color color, int amount) {
        int r = Math.min(255, color.getRed() + amount);
        int g = Math.min(255, color.getGreen() + amount);
        int b = Math.min(255, color.getBlue() + amount);
        return new Color(r, g, b, color.getAlpha());
    }

    private abstract static class PromptSupport {
        protected String prompt;

        protected PromptSupport(String prompt) {
            this.prompt = prompt;
        }

        protected void paintPrompt(JTextComponent component, Graphics g) {
            if (prompt == null || prompt.isEmpty() || component.getText().length() > 0) {
                return;
            }
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setColor(MUTED);
            g2.setFont(component.getFont());
            FontMetrics fm = g2.getFontMetrics();
            Insets insets = component.getInsets();
            int y = insets.top + fm.getAscent();
            if (component instanceof JTextArea) {
                y += 2;
            }
            g2.drawString(prompt, insets.left, y);
            g2.dispose();
        }
    }

    private static class PromptTextField extends JTextField {
        private final PromptSupport support;

        private PromptTextField(String prompt) {
            super();
            this.support = new PromptSupport(prompt) {
            };
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            support.paintPrompt(this, g);
        }
    }

    private static class PromptPasswordField extends JPasswordField {
        private final PromptSupport support;

        private PromptPasswordField(String prompt) {
            super();
            this.support = new PromptSupport(prompt) {
            };
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (getPassword().length == 0) {
                support.paintPrompt(this, g);
            }
        }
    }

    private static class PromptTextArea extends JTextArea {
        private final PromptSupport support;

        private PromptTextArea(String prompt) {
            super();
            this.support = new PromptSupport(prompt) {
            };
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            support.paintPrompt(this, g);
        }
    }

    private static class AtlasComboBoxUI extends BasicComboBoxUI {
        public static ComponentUI createUI(JComponent c) {
            return new AtlasComboBoxUI();
        }

        @Override
        protected JButton createArrowButton() {
            JButton button = new JButton("▼");
            button.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 8));
            button.setContentAreaFilled(false);
            button.setBorderPainted(false);
            button.setFocusPainted(false);
            button.setOpaque(false);
            button.setForeground(MUTED);
            button.setFont(fontBold(10));
            return button;
        }

        @Override
        public void paintCurrentValueBackground(Graphics g, Rectangle bounds, boolean hasFocus) {
        }
    }

    private static class AtlasSpinnerUI extends BasicSpinnerUI {
        @Override
        protected Component createNextButton() {
            JButton button = createSpinnerArrowButton(SwingConstants.NORTH);
            installNextButtonListeners(button);
            return button;
        }

        @Override
        protected Component createPreviousButton() {
            JButton button = createSpinnerArrowButton(SwingConstants.SOUTH);
            installPreviousButtonListeners(button);
            return button;
        }

        private JButton createSpinnerArrowButton(final int direction) {
            JButton button = new JButton() {
                @Override
                protected void paintComponent(Graphics g) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(MUTED);
                    int w = getWidth();
                    int h = getHeight();
                    int s = Math.max(4, Math.min(7, Math.min(w, h) - 2));
                    int cx = w / 2;
                    int cy = h / 2;
                    Polygon p = new Polygon();
                    if (direction == SwingConstants.NORTH) {
                        p.addPoint(cx - s / 2, cy + s / 4);
                        p.addPoint(cx + s / 2, cy + s / 4);
                        p.addPoint(cx, cy - s / 2);
                    } else {
                        p.addPoint(cx - s / 2, cy - s / 4);
                        p.addPoint(cx + s / 2, cy - s / 4);
                        p.addPoint(cx, cy + s / 2);
                    }
                    g2.fillPolygon(p);
                    g2.dispose();
                }
            };
            button.setOpaque(false);
            button.setContentAreaFilled(false);
            button.setBorderPainted(false);
            button.setFocusPainted(false);
            button.setFocusable(false);
            button.setBorder(BorderFactory.createEmptyBorder(1, 3, 1, 3));
            button.setPreferredSize(new Dimension(22, 0));
            button.setMinimumSize(new Dimension(22, 4));
            return button;
        }
    }
}
