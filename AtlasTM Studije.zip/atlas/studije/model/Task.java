package atlas.studije.model;

import java.time.LocalDate;

public class Task {
    private int id;
    private int userId;
    private String title;
    private String description;
    private LocalDate date;
    private boolean completed;

    public Task() {
        this.id = 0;
        this.userId = 0;
        this.title = "";
        this.description = "";
        this.date = LocalDate.now();
        this.completed = false;
    }

    public Task copy() {
        Task task = new Task();
        task.id = id;
        task.userId = userId;
        task.title = title;
        task.description = description;
        task.date = date;
        task.completed = completed;
        return task;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title == null ? "" : title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description == null ? "" : description;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date == null ? LocalDate.now() : date;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }
}
