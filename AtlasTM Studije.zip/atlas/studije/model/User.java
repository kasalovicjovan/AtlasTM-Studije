package atlas.studije.model;

public class User {
    private int id;
    private String username;

    public User() {
        this(0, "");
    }

    public User(int id, String username) {
        this.id = id;
        this.username = username == null ? "" : username;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? "" : username;
    }

    public void copyFrom(User other) {
        if (other == null) {
            this.id = 0;
            this.username = "";
            return;
        }
        this.id = other.id;
        this.username = other.username;
    }
}
