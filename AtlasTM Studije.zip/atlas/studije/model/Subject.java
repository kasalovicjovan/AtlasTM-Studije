package atlas.studije.model;

import java.util.ArrayList;
import java.util.List;

public class Subject {
    private int id;
    private int userId;
    private String name;
    private int semester;
    private int year;
    private int ects;
    private double grade;
    private SubjectStatus status;
    private String notes;
    private List<PointEntry> pointEntries;

    public Subject() {
        this.id = 0;
        this.userId = 0;
        this.name = "";
        this.semester = 1;
        this.year = 1;
        this.ects = 0;
        this.grade = 0.0;
        this.status = SubjectStatus.IN_PROGRESS;
        this.notes = "";
        this.pointEntries = new ArrayList<PointEntry>();
    }

    public Subject copy() {
        Subject copy = new Subject();
        copy.id = id;
        copy.userId = userId;
        copy.name = name;
        copy.semester = semester;
        copy.year = year;
        copy.ects = ects;
        copy.grade = grade;
        copy.status = status;
        copy.notes = notes;
        copy.pointEntries = new ArrayList<PointEntry>();
        for (PointEntry entry : pointEntries) {
            copy.pointEntries.add(entry.copy());
        }
        return copy;
    }

    public double totalPoints() {
        double sum = 0.0;
        for (PointEntry entry : pointEntries) {
            if (entry != null) {
                sum += entry.getPoints();
            }
        }
        return sum;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? "" : name;
    }

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getEcts() {
        return ects;
    }

    public void setEcts(int ects) {
        this.ects = ects;
    }

    public double getGrade() {
        return grade;
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }

    public SubjectStatus getStatus() {
        return status;
    }

    public void setStatus(SubjectStatus status) {
        this.status = status == null ? SubjectStatus.IN_PROGRESS : status;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes == null ? "" : notes;
    }

    public List<PointEntry> getPointEntries() {
        return pointEntries;
    }

    public void setPointEntries(List<PointEntry> pointEntries) {
        this.pointEntries = pointEntries == null ? new ArrayList<PointEntry>() : pointEntries;
    }

    public static class PointEntry {
        private String description;
        private double points;

        public PointEntry() {
            this("", 0.0);
        }

        public PointEntry(String description, double points) {
            this.description = description == null ? "" : description;
            this.points = points;
        }

        public PointEntry copy() {
            return new PointEntry(description, points);
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description == null ? "" : description;
        }

        public double getPoints() {
            return points;
        }

        public void setPoints(double points) {
            this.points = points;
        }
    }
}
