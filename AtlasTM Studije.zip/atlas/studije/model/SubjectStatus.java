package atlas.studije.model;

public enum SubjectStatus {
    IN_PROGRESS(1, "У току", "#2C425F"),
    PASSED(2, "Положен", "#FFFFFF"),
    FAILED(3, "Није положен", "#2C425F");

    private final int code;
    private final String displayName;
    private final String color;

    SubjectStatus(int code, String displayName, String color) {
        this.code = code;
        this.displayName = displayName;
        this.color = color;
    }

    public int getCode() {
        return code;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getColor() {
        return color;
    }

    public static SubjectStatus fromCode(int code) {
        for (SubjectStatus status : values()) {
            if (status.code == code) {
                return status;
            }
        }
        return IN_PROGRESS;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
