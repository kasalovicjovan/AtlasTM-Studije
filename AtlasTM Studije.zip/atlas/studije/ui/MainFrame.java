package atlas.studije.ui;

import atlas.studije.DataManager;
import atlas.studije.Main;
import atlas.studije.model.Subject;
import atlas.studije.model.SubjectStatus;
import atlas.studije.model.Task;
import atlas.studije.model.User;
import atlas.studije.util.Theme;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSplitPane;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.ListCellRenderer;
import javax.swing.KeyStroke;
import javax.swing.Timer;
import javax.swing.plaf.basic.BasicSplitPaneDivider;
import javax.swing.plaf.basic.BasicSplitPaneUI;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.RenderingHints;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainFrame extends JFrame {
    private static final Color STATUS_RED = Theme.DANGER;
    private static final Color DANGER_TEXT = Theme.DANGER_DARK;

    private final User currentUser;
    private final DefaultListModel<Task> taskModel;
    private final JList<Task> taskList;
    private final JPanel taskContainer;
    private final JPanel subjectsContainer;
    private JSplitPane splitPane;
    private Timer splitPaneAnimationTimer;
    private int expandedDividerLocation = 300;
    private boolean tasksCollapsed = false;
    private JLabel usernameStatusLabel;
    private JLabel statsStatusLabel;
    private JLabel tasksTitleLabel;
    private JButton tasksToggleButton;
    private JButton tasksAddButton;
    private SlideFadePanel tasksPanel;

    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy", Locale.US);

    public MainFrame(User user) {
        super("AtlasTM: Studije  ·  " + user.getUsername());
        this.currentUser = new User(user.getId(), user.getUsername());
        this.taskModel = new DefaultListModel<Task>();

        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setSize(1150, 700);
        setMinimumSize(new Dimension(900, 580));
        setLocationRelativeTo(null);
        Theme.applyWindow(this);
        Image icon = Main.loadLogo();
        if (icon != null) {
            setIconImage(icon);
        }

        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                handleExit();
            }
        });

        JPanel root = new Theme.BackgroundPanel(new BorderLayout());
        root.add(buildNavigationBar(), BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout());
        center.setOpaque(false);
        center.add(buildStatusBar(), BorderLayout.NORTH);

        taskList = new JList<Task>(taskModel);
        Theme.applyList(taskList);
        taskList.setCellRenderer(new TaskRenderer());

        taskContainer = new JPanel(new BorderLayout());
        taskContainer.setOpaque(false);
        updateTaskContainer();

        subjectsContainer = new JPanel();
        subjectsContainer.setOpaque(false);
        subjectsContainer.setLayout(new BoxLayout(subjectsContainer, BoxLayout.Y_AXIS));

        JScrollPane subjectsScroll = new JScrollPane(subjectsContainer);
        Theme.applyScrollPane(subjectsScroll);
        subjectsScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        subjectsScroll.getViewport().addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                SwingUtilities.invokeLater(() -> reflowSubjectsNow());
            }
        });

        JPanel leftPanel = buildTasksPanel();
        JPanel rightPanel = buildSubjectsPanel(subjectsScroll);

        splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, rightPanel);
        splitPane.setResizeWeight(0.27);
        splitPane.setContinuousLayout(true);
        splitPane.setDividerLocation(expandedDividerLocation);
        splitPane.setUI(new BasicSplitPaneUI() {
            @Override
            public BasicSplitPaneDivider createDefaultDivider() {
                BasicSplitPaneDivider divider = new BasicSplitPaneDivider(this) {
                    @Override
                    public void paint(Graphics g) {
                        Graphics2D g2 = (Graphics2D) g.create();
                        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                        int lineX = Math.max(0, (getWidth() - 1) / 2);
                        int mid = getHeight() / 2;
                        GradientPaint top = new GradientPaint(
                                0, 0, new Color(128, 183, 255, 0),
                                0, mid, new Color(128, 183, 255, 34)
                        );
                        g2.setPaint(top);
                        g2.fillRect(lineX, 0, 1, mid);
                        GradientPaint bot = new GradientPaint(
                                0, mid, new Color(128, 183, 255, 34),
                                0, getHeight(), new Color(128, 183, 255, 0)
                        );
                        g2.setPaint(bot);
                        g2.fillRect(lineX, mid, 1, getHeight() - mid);
                        g2.dispose();
                    }
                };
                divider.setCursor(Cursor.getPredefinedCursor(Cursor.E_RESIZE_CURSOR));
                return divider;
            }
        });
        splitPane.setDividerSize(8);
        splitPane.setBorder(null);
        splitPane.setOpaque(false);
        splitPane.setBackground(new Color(0, 0, 0, 0));
        splitPane.addPropertyChangeListener(JSplitPane.DIVIDER_LOCATION_PROPERTY, e -> {
            if (!isSplitPaneAnimating()) {
                int location = splitPane.getDividerLocation();
                if (location > 100) {
                    expandedDividerLocation = location;
                    tasksCollapsed = false;
                } else {
                    tasksCollapsed = true;
                }
                updateTasksToggleButton();
                SwingUtilities.invokeLater(() -> reflowSubjectsNow());
            }
        });
        center.add(splitPane, BorderLayout.CENTER);

        root.add(center, BorderLayout.CENTER);
        setContentPane(root);

        refreshAll();
        installTaskInteractions();
        installEscapeBindings();
    }

    private void installEscapeBindings() {
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_ESCAPE, 0), "atlas.openProfile");
        getRootPane().getActionMap().put("atlas.openProfile", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleProfile();
            }
        });
    }

    private void installEscapeToClose(final JDialog dialog) {
        dialog.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_ESCAPE, 0), "atlas.closeDialog");
        dialog.getRootPane().getActionMap().put("atlas.closeDialog", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });
    }

    private JPanel buildNavigationBar() {
        JPanel nav = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                g2.setColor(new Color(4, 7, 12, 168));
                g2.fillRect(0, 0, getWidth(), getHeight());

                GradientPaint bottomLine = new GradientPaint(
                        0, getHeight() - 1, new Color(128, 183, 255, 40),
                        getWidth(), getHeight() - 1, new Color(217, 177, 92, 20)
                );
                g2.setPaint(bottomLine);
                g2.fillRect(0, getHeight() - 1, getWidth(), 1);

                g2.dispose();
                super.paintComponent(g);
            }
        };
        nav.setOpaque(false);
        nav.setPreferredSize(new Dimension(10, 62));
        nav.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 11));
        left.setOpaque(false);
        ImageIcon icon = Main.scaledLogoIcon(30);
        if (icon != null) {
            JLabel logo = new JLabel(icon);
            logo.setMinimumSize(new Dimension(30, 30));
            logo.setPreferredSize(new Dimension(30, 30));
            logo.setMaximumSize(new Dimension(30, 30));
            left.add(logo);
        }

        JPanel brandText = new JPanel();
        brandText.setOpaque(false);
        brandText.setLayout(new BoxLayout(brandText, BoxLayout.Y_AXIS));
        JLabel title = new JLabel("ATLAS");
        title.setForeground(Theme.TEXT);
        title.setFont(Theme.brandFont(15));
        JLabel subtitle = new JLabel("IT технологије и услуге");
        subtitle.setForeground(Theme.MUTED);
        subtitle.setFont(Theme.fontPlain(10));
        brandText.add(title);
        brandText.add(Box.createVerticalStrut(1));
        brandText.add(subtitle);
        left.add(brandText);

        JPanel center = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 12));
        center.setOpaque(false);

        JButton profileButton = Theme.navButton("Профил");
        JButton subjectButton = Theme.navButton("Предмети");
        JButton taskButton = Theme.navButton("Обавезе");
        JButton yearSemesterButton = Theme.navButton("Семестри");

        profileButton.addActionListener(e -> handleProfile());
        subjectButton.addActionListener(e -> handleAddSubject());
        taskButton.addActionListener(e -> handleAddTask());
        yearSemesterButton.addActionListener(e -> handleYearSemester());

        center.add(profileButton);
        center.add(subjectButton);
        center.add(taskButton);
        center.add(yearSemesterButton);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 12));
        right.setOpaque(false);

        JButton settingsButton = Theme.navButton("Подешавања");
        JButton exitButton = Theme.navButton("Заврши рад");
        settingsButton.setIcon(Theme.settingsIcon(12, Theme.MUTED));
        settingsButton.setIconTextGap(6);
        exitButton.setIcon(Theme.logoutIcon(12, DANGER_TEXT));
        exitButton.setIconTextGap(6);
        exitButton.putClientProperty("navBaseForeground", DANGER_TEXT);

        settingsButton.addActionListener(e -> handleSettings());
        exitButton.addActionListener(e -> handleExit());

        right.add(settingsButton);
        right.add(makeNavSeparator());
        right.add(exitButton);

        nav.add(left, BorderLayout.WEST);
        nav.add(center, BorderLayout.CENTER);
        nav.add(right, BorderLayout.EAST);
        return nav;
    }

    private JPanel buildStatusBar() {
        JPanel statusBar = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(new Color(10, 16, 28, 120));
                g2.fillRect(0, 0, getWidth(), getHeight());

                GradientPaint divider = new GradientPaint(
                        0, getHeight() - 1, new Color(128, 183, 255, 0),
                        getWidth() * 0.5f, getHeight() - 1, new Color(128, 183, 255, 35),
                        true
                );
                g2.setPaint(divider);
                g2.fillRect(0, getHeight() - 1, getWidth(), 1);

                g2.dispose();
                super.paintComponent(g);
            }
        };
        statusBar.setOpaque(false);
        statusBar.setPreferredSize(new Dimension(10, 32));
        statusBar.setBorder(BorderFactory.createEmptyBorder(5, 20, 5, 20));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        left.setOpaque(false);
        JLabel bullet = new JLabel("●");
        bullet.setForeground(Theme.GOLD);
        bullet.setFont(Theme.fontBold(10));
        usernameStatusLabel = new JLabel(currentUser.getUsername());
        usernameStatusLabel.setForeground(Theme.TEXT);
        usernameStatusLabel.setFont(Theme.fontBold(11));
        left.add(bullet);
        left.add(Box.createHorizontalStrut(6));
        left.add(usernameStatusLabel);

        statsStatusLabel = new JLabel();
        statsStatusLabel.setForeground(Theme.MUTED);
        statsStatusLabel.setFont(Theme.fontPlain(11));
        statsStatusLabel.setHorizontalAlignment(SwingConstants.RIGHT);

        statusBar.add(left, BorderLayout.WEST);
        statusBar.add(statsStatusLabel, BorderLayout.EAST);
        return statusBar;
    }

    private JPanel buildTasksPanel() {
        tasksPanel = new SlideFadePanel(new BorderLayout(0, 12));
        tasksPanel.setOpaque(false);
        tasksPanel.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 10));

        JPanel header = new JPanel(new BorderLayout(8, 0));
        header.setOpaque(false);

        JPanel titleRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        titleRow.setOpaque(false);
        tasksTitleLabel = new JLabel("Обавезе");
        tasksTitleLabel.setForeground(Theme.TEXT);
        tasksTitleLabel.setFont(Theme.fontBold(16));
        titleRow.add(tasksTitleLabel);

        tasksAddButton = Theme.primaryButton("+ Додај обавезу");
        tasksAddButton.setPreferredSize(new Dimension(160, 36));
        tasksAddButton.setMinimumSize(new Dimension(38, 36));
        tasksAddButton.addActionListener(e -> handleAddTask());
        header.add(titleRow, BorderLayout.WEST);
        header.add(tasksAddButton, BorderLayout.EAST);

        tasksPanel.add(header, BorderLayout.NORTH);
        tasksPanel.add(taskContainer, BorderLayout.CENTER);
        tasksPanel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                updateTasksHeaderLayout();
            }
        });
        updateTasksToggleButton();
        updateTasksHeaderLayout();
        return tasksPanel;
    }

    private JPanel buildSubjectsPanel(JScrollPane subjectsScroll) {
        JPanel panel = new JPanel(new BorderLayout(0, 12));
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(16, 10, 16, 20));

        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        JLabel title = new JLabel("Предмети и оцене");
        title.setForeground(Theme.TEXT);
        title.setFont(Theme.fontBold(16));
        JButton addButton = Theme.primaryButton("+ Додај предмет");
        addButton.setPreferredSize(new Dimension(160, 36));
        addButton.addActionListener(e -> handleAddSubject());
        header.add(title, BorderLayout.WEST);
        header.add(addButton, BorderLayout.EAST);

        panel.add(header, BorderLayout.NORTH);
        panel.add(subjectsScroll, BorderLayout.CENTER);
        return panel;
    }

    private Component makeNavSeparator() {
        JPanel sep = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                GradientPaint top = new GradientPaint(
                        0, 0, new Color(128, 183, 255, 0),
                        0, getHeight() / 2.0f, new Color(128, 183, 255, 26)
                );
                g2.setPaint(top);
                g2.fillRect(0, 0, getWidth(), getHeight() / 2);
                GradientPaint bottom = new GradientPaint(
                        0, getHeight() / 2.0f, new Color(128, 183, 255, 26),
                        0, getHeight(), new Color(128, 183, 255, 0)
                );
                g2.setPaint(bottom);
                g2.fillRect(0, getHeight() / 2, getWidth(), getHeight() - getHeight() / 2);
                g2.dispose();
            }
        };
        sep.setOpaque(false);
        sep.setPreferredSize(new Dimension(1, 20));
        sep.setMinimumSize(new Dimension(1, 20));
        sep.setMaximumSize(new Dimension(1, 20));
        return sep;
    }

    private JPanel buildEmptyState(String icon, String line1, String line2) {
        JPanel panel = new JPanel();
        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(40, 20, 40, 20));

        JLabel iconLabel = new JLabel(icon);
        iconLabel.setFont(Theme.fontPlain(32));
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel l1 = new JLabel(line1);
        l1.setForeground(Theme.TEXT);
        l1.setFont(Theme.fontBold(14));
        l1.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel l2 = new JLabel(line2);
        l2.setForeground(Theme.MUTED);
        l2.setFont(Theme.fontPlain(12));
        l2.setAlignmentX(Component.CENTER_ALIGNMENT);

        panel.add(iconLabel);
        panel.add(Box.createVerticalStrut(10));
        panel.add(l1);
        panel.add(Box.createVerticalStrut(4));
        panel.add(l2);
        return panel;
    }

    private void installTaskInteractions() {
        final JPopupMenu popupMenu = new JPopupMenu();
        popupMenu.setBorder(new Theme.RoundedBorder(Theme.BORDER, 1, 6));
        popupMenu.setBackground(Theme.BG_CARD);
        JMenuItem editItem = new JMenuItem("Измени");
        JMenuItem deleteItem = new JMenuItem("Обриши");
        styleMenuItem(editItem);
        styleMenuItem(deleteItem);
        popupMenu.add(editItem);
        popupMenu.add(deleteItem);

        editItem.addActionListener(e -> {
            Task task = taskList.getSelectedValue();
            if (task != null) {
                openTaskDialog(task);
            }
        });
        deleteItem.addActionListener(e -> {
            Task task = taskList.getSelectedValue();
            if (task != null) {
                DataManager.getInstance().deleteTask(task.getId());
                refreshAll();
            }
        });

        taskList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int index = taskList.locationToIndex(e.getPoint());
                if (index < 0) {
                    return;
                }
                taskList.setSelectedIndex(index);
                Rectangle bounds = taskList.getCellBounds(index, index);
                if (bounds == null || !bounds.contains(e.getPoint())) {
                    return;
                }
                Task task = taskModel.getElementAt(index);
                if (e.getButton() == MouseEvent.BUTTON1 && e.getClickCount() == 1 && e.getX() < bounds.x + 52) {
                    Task updated = task.copy();
                    updated.setCompleted(!updated.isCompleted());
                    DataManager.getInstance().updateTask(updated);
                    refreshAll();
                } else if (e.getButton() == MouseEvent.BUTTON1 && e.getClickCount() == 2) {
                    openTaskDialog(task);
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {
                showPopupIfNeeded(e);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                showPopupIfNeeded(e);
            }

            private void showPopupIfNeeded(MouseEvent e) {
                if (!e.isPopupTrigger()) {
                    return;
                }
                int index = taskList.locationToIndex(e.getPoint());
                if (index >= 0) {
                    taskList.setSelectedIndex(index);
                    popupMenu.show(taskList, e.getX(), e.getY());
                }
            }
        });
    }

    private void styleMenuItem(JMenuItem item) {
        item.setOpaque(true);
        item.setBackground(Theme.BG_CARD);
        item.setForeground(Theme.TEXT);
        item.setFont(Theme.fontPlain(13));
    }

    private void refreshAll() {
        refreshTasks();
        refreshSubjects();
        refreshStatusBar();
    }

    private void refreshTasks() {
        taskModel.clear();
        List<Task> tasks = DataManager.getInstance().getTasks(currentUser.getId());
        int i;
        for (i = 0; i < tasks.size(); i++) {
            taskModel.addElement(tasks.get(i));
        }
        updateTaskContainer();
    }

    private void updateTaskContainer() {
        taskContainer.removeAll();
        if (taskModel.isEmpty()) {
            JPanel placeholder = Theme.surfaceCard(new BorderLayout());
            placeholder.add(buildEmptyState("✔", "Нема обавеза", "Притисни + да додаш прву"), BorderLayout.CENTER);
            taskContainer.add(placeholder, BorderLayout.CENTER);
        } else {
            JScrollPane scrollPane = new JScrollPane(taskList);
            Theme.applyScrollPane(scrollPane);
            taskContainer.add(scrollPane, BorderLayout.CENTER);
        }
        taskContainer.revalidate();
        taskContainer.repaint();
    }

    private void refreshSubjects() {
        subjectsContainer.removeAll();
        List<Subject> subjects = DataManager.getInstance().getSubjects(currentUser.getId());
        if (subjects.isEmpty()) {
            JPanel placeholder = Theme.surfaceCard(new BorderLayout());
            placeholder.add(buildEmptyState("📚", "Нема предмета", "Додај први предмет"), BorderLayout.CENTER);
            placeholder.setMaximumSize(new Dimension(Integer.MAX_VALUE, 170));
            placeholder.setAlignmentX(Component.LEFT_ALIGNMENT);
            subjectsContainer.add(placeholder);
        } else {
            Map<String, List<Subject>> groups = new LinkedHashMap<String, List<Subject>>();
            int i;
            for (i = 0; i < subjects.size(); i++) {
                Subject subject = subjects.get(i);
                String key = subject.getYear() + "|" + subject.getSemester();
                if (!groups.containsKey(key)) {
                    groups.put(key, new ArrayList<Subject>());
                }
                groups.get(key).add(subject);
            }
            for (Map.Entry<String, List<Subject>> entry : groups.entrySet()) {
                String[] parts = entry.getKey().split("\\|");
                int year = Integer.parseInt(parts[0]);
                int semester = Integer.parseInt(parts[1]);
                JPanel groupPanel = new JPanel();
                groupPanel.setOpaque(false);
                groupPanel.setLayout(new BoxLayout(groupPanel, BoxLayout.Y_AXIS));
                groupPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

                JLabel header = new JLabel(year + ". година · " + semester + ". семестар");
                header.setForeground(Theme.MUTED);
                header.setFont(Theme.fontBold(11));
                header.setAlignmentX(Component.LEFT_ALIGNMENT);
                groupPanel.add(header);
                groupPanel.add(Box.createVerticalStrut(6));
                JPanel gradSep = gradientSeparator();
                gradSep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
                groupPanel.add(gradSep);
                groupPanel.add(Box.createVerticalStrut(10));

                JPanel cards = new JPanel(new WrapFlowLayout(FlowLayout.LEFT, 12, 12));
                cards.setOpaque(false);
                List<Subject> groupSubjects = entry.getValue();
                for (i = 0; i < groupSubjects.size(); i++) {
                    cards.add(createSubjectCard(groupSubjects.get(i)));
                }
                cards.setAlignmentX(Component.LEFT_ALIGNMENT);
                groupPanel.add(cards);
                groupPanel.add(Box.createVerticalStrut(12));
                subjectsContainer.add(groupPanel);
            }
        }
        subjectsContainer.revalidate();
        subjectsContainer.repaint();
    }

    private JPanel createSubjectCard(final Subject subject) {
        final Theme.RoundedPanel card = new Theme.RoundedPanel(new BorderLayout(0, 10));
        card.setBackground(new Color(10, 16, 28, 214));
        card.setBorder(BorderFactory.createCompoundBorder(
                new Theme.RoundedBorder(Theme.BORDER, 1, 14),
                BorderFactory.createEmptyBorder(12, 12, 12, 12)
        ));
        card.setRadius(14);
        card.setPreferredSize(new Dimension(280, 200));
        card.setMaximumSize(new Dimension(280, 200));

        JPanel headerRow = createCardHeader(subject.totalPoints(), subject.getStatus());

        JLabel nameLabel = createWrappedTitleLabel(subject.getName(), 236, Theme.fontBold(11), Theme.TEXT, false);
        nameLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel topBlock = new JPanel();
        topBlock.setOpaque(false);
        topBlock.setLayout(new BoxLayout(topBlock, BoxLayout.Y_AXIS));
        topBlock.setAlignmentX(Component.LEFT_ALIGNMENT);
        headerRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        topBlock.add(headerRow);
        topBlock.add(Box.createVerticalStrut(6));
        topBlock.add(nameLabel);

        JPanel separator = gradientSeparator();
        separator.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel stats = new JPanel(new GridLayout(1, 3, 8, 0));
        stats.setOpaque(false);
        stats.setAlignmentX(Component.LEFT_ALIGNMENT);
        stats.add(createStatBox("ЕСПБ", String.valueOf(subject.getEcts())));
        stats.add(createStatBox("ОЦЕНА", subject.getGrade() == 0.0 ? "--" : String.format(Locale.US, "%.1f", subject.getGrade())));
        stats.add(createStatBox("ПОЕНИ", String.format(Locale.US, "%.1f", subject.totalPoints())));

        JLabel notesLabel = Theme.mutedLabel(truncate(subject.getNotes(), 60));
        notesLabel.setFont(Theme.fontPlain(12).deriveFont(Font.ITALIC));
        notesLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttons.setOpaque(false);
        JButton editButton = Theme.secondaryButton("Измени");
        JButton deleteButton = Theme.dangerButton("");
        deleteButton.setIcon(Theme.trashIcon(14, 14, Theme.DANGER));
        editButton.setPreferredSize(new Dimension(78, 28));
        deleteButton.setPreferredSize(new Dimension(44, 28));
        deleteButton.setIconTextGap(0);
        editButton.addActionListener(e -> openSubjectDialog(subject));
        deleteButton.addActionListener(e -> {
            DataManager.getInstance().deleteSubject(subject.getId());
            refreshAll();
        });
        buttons.add(editButton);
        buttons.add(deleteButton);

        JPanel center = new JPanel();
        center.setOpaque(false);
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.add(topBlock);
        center.add(Box.createVerticalStrut(8));
        center.add(separator);
        center.add(Box.createVerticalStrut(10));
        center.add(stats);
        center.add(Box.createVerticalStrut(10));
        if (!subject.getNotes().trim().isEmpty()) {
            center.add(notesLabel);
            center.add(Box.createVerticalGlue());
        } else {
            center.add(Box.createVerticalGlue());
        }

        card.add(center, BorderLayout.CENTER);
        card.add(buttons, BorderLayout.SOUTH);

        MouseAdapter hover = new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                card.setBorder(BorderFactory.createCompoundBorder(
                        new Theme.RoundedBorder(Theme.BORDER_FOCUS, 1, 14),
                        BorderFactory.createEmptyBorder(12, 12, 12, 12)
                ));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                card.setBorder(BorderFactory.createCompoundBorder(
                        new Theme.RoundedBorder(Theme.BORDER, 1, 14),
                        BorderFactory.createEmptyBorder(12, 12, 12, 12)
                ));
            }
        };
        card.addMouseListener(hover);
        nameLabel.addMouseListener(hover);
        center.addMouseListener(hover);
        buttons.addMouseListener(hover);
        return card;
    }

    private JPanel createCardHeader(final double totalPoints, SubjectStatus status) {
        final SubjectStatus safeStatus = status == null ? SubjectStatus.IN_PROGRESS : status;
        final JPanel badge = createStatusBadge(safeStatus);

        JPanel header = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int badgeX = badge.getX() > 0 ? badge.getX() : Math.max(0, getWidth() - badge.getPreferredSize().width);
                int trackEnd = Math.max(36, badgeX - 1);

                int lineHeight = 4;
                int lineY = 6;
                Color trackColor = new Color(Theme.BORDER.getRed(), Theme.BORDER.getGreen(), Theme.BORDER.getBlue(), 115);
                g2.setColor(trackColor);
                g2.fillRoundRect(0, lineY, trackEnd, lineHeight, 4, 4);

                double ratio = totalPoints / 100.0;
                if (ratio < 0.0) {
                    ratio = 0.0;
                }
                if (ratio > 1.0) {
                    ratio = 1.0;
                }
                int fillWidth = (int) Math.round(trackEnd * ratio);
                if (fillWidth > 0) {
                    g2.setColor(Theme.GOLD);
                    g2.fillRoundRect(0, lineY, fillWidth, lineHeight, 4, 4);
                }
                g2.dispose();
            }

            @Override
            public void doLayout() {
                Dimension size = badge.getPreferredSize();
                int x = Math.max(0, getWidth() - size.width);
                badge.setBounds(x, 0, size.width, size.height);
            }
        };
        header.setOpaque(false);
        header.setPreferredSize(new Dimension(256, 22));
        header.setMinimumSize(new Dimension(60, 22));
        header.setMaximumSize(new Dimension(Integer.MAX_VALUE, 22));
        header.add(badge);
        return header;
    }

    private JPanel createStatusBadge(SubjectStatus status) {
        SubjectStatus safeStatus = status == null ? SubjectStatus.IN_PROGRESS : status;
        Color fill;
        Color textColor;
        Color borderColor = Theme.BORDER;
        String badgeText;
        if (safeStatus == SubjectStatus.PASSED) {
            fill = new Color(0x3D, 0xBE, 0x7A, 0x22);
            textColor = Theme.SUCCESS;
            badgeText = "Полож.";
        } else if (safeStatus == SubjectStatus.FAILED) {
            fill = new Color(0xC0, 0x50, 0x4A, 0x22);
            textColor = Theme.DANGER;
            badgeText = "Није пол.";
        } else {
            fill = new Color(0xC9, 0xA8, 0x4C, 0x22);
            textColor = Theme.ACCENT;
            badgeText = "У току";
        }

        Theme.RoundedPanel badge = new Theme.RoundedPanel(new BorderLayout());
        badge.setBackground(fill);
        badge.setShadow(false);
        badge.setRadius(8);
        badge.setBorder(BorderFactory.createCompoundBorder(
                new Theme.RoundedBorder(borderColor, 1, 8),
                BorderFactory.createEmptyBorder(0, 4, 0, 4)
        ));
        badge.setPreferredSize(new Dimension(56, 20));
        badge.setMinimumSize(new Dimension(56, 20));
        badge.setMaximumSize(new Dimension(56, 20));
        JLabel label = new JLabel(badgeText, SwingConstants.CENTER);
        label.setForeground(textColor);
        label.setFont(Theme.fontBold(8));
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setVerticalAlignment(SwingConstants.CENTER);
        badge.add(label, BorderLayout.CENTER);
        return badge;
    }

    private JPanel createStatBox(String key, String value) {
        JPanel box = new JPanel();
        box.setOpaque(false);
        box.setLayout(new BoxLayout(box, BoxLayout.Y_AXIS));
        JLabel valueLabel = new JLabel(value);
        valueLabel.setForeground(Theme.TEXT);
        valueLabel.setFont(Theme.fontBold(18));
        valueLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel keyLabel = new JLabel(key);
        keyLabel.setForeground(Theme.MUTED);
        keyLabel.setFont(Theme.fontBold(10));
        keyLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        box.add(valueLabel);
        box.add(Box.createVerticalStrut(2));
        box.add(keyLabel);
        return box;
    }

    private String truncate(String text, int max) {
        String safe = text == null ? "" : text.trim();
        if (safe.length() <= max) {
            return safe;
        }
        return safe.substring(0, Math.max(0, max - 3)) + "...";
    }

    private JLabel createWrappedTitleLabel(String text, int width, Font font, Color color, boolean strikeThrough) {
        JLabel label = new JLabel(buildWrappedHtml(text, width, font, color, strikeThrough));
        label.setFont(font);
        label.setForeground(color);
        label.setVerticalAlignment(SwingConstants.TOP);
        return label;
    }

    private String buildWrappedHtml(String text, int width, Font font, Color color, boolean strikeThrough) {
        String safeText = escapeHtml(text == null ? "" : text).replace("\n", "<br>");
        String decoration = strikeThrough ? "text-decoration:line-through;" : "";
        return "<html><div style='width:" + width + "px;color:" + toHex(color)
                + ";font-family:SansSerif;font-size:" + font.getSize() + "px;font-weight:"
                + (font.isBold() ? "700" : "400") + ";line-height:1.15;" + decoration + "'>"
                + safeText + "</div></html>";
    }

    private String toHex(Color color) {
        if (color == null) {
            return "#FFFFFF";
        }
        return String.format("#%02X%02X%02X", color.getRed(), color.getGreen(), color.getBlue());
    }

    private void reflowSubjectsNow() {
        if (subjectsContainer == null) {
            return;
        }
        invalidateDescendants(subjectsContainer);
        subjectsContainer.revalidate();
        subjectsContainer.repaint();
    }

    private void invalidateDescendants(Container container) {
        Component[] components = container.getComponents();
        int i;
        for (i = 0; i < components.length; i++) {
            components[i].invalidate();
            if (components[i] instanceof Container) {
                invalidateDescendants((Container) components[i]);
            }
        }
    }

    private boolean isSplitPaneAnimating() {
        return splitPaneAnimationTimer != null && splitPaneAnimationTimer.isRunning();
    }

    private void updateTasksHeaderLayout() {
        if (tasksAddButton == null || tasksTitleLabel == null) {
            return;
        }

        int panelWidth = tasksPanel != null ? tasksPanel.getWidth() : 0;
        if (panelWidth <= 0 && splitPane != null) {
            panelWidth = splitPane.getDividerLocation();
        }

        if (panelWidth > 0 && panelWidth < 190) {
            tasksTitleLabel.setText("");
            tasksAddButton.setText("+");
            tasksAddButton.setToolTipText("Додај обавезу");
            tasksAddButton.setFont(Theme.fontBold(18));
            tasksAddButton.setMargin(new Insets(0, 0, 0, 0));
            tasksAddButton.setPreferredSize(new Dimension(38, 36));
            tasksAddButton.setMaximumSize(new Dimension(38, 36));
        } else if (panelWidth > 0 && panelWidth < 270) {
            tasksTitleLabel.setText("Обавезе");
            tasksAddButton.setText("+");
            tasksAddButton.setToolTipText("Додај обавезу");
            tasksAddButton.setFont(Theme.fontBold(18));
            tasksAddButton.setMargin(new Insets(0, 0, 0, 0));
            tasksAddButton.setPreferredSize(new Dimension(44, 36));
            tasksAddButton.setMaximumSize(new Dimension(44, 36));
        } else {
            tasksTitleLabel.setText("Обавезе");
            tasksAddButton.setText("+ Додај обавезу");
            tasksAddButton.setToolTipText(null);
            tasksAddButton.setFont(Theme.fontBold(13));
            tasksAddButton.setMargin(new Insets(8, 12, 8, 12));
            tasksAddButton.setPreferredSize(new Dimension(160, 36));
            tasksAddButton.setMaximumSize(new Dimension(160, 36));
        }

        if (tasksPanel != null) {
            tasksPanel.revalidate();
            tasksPanel.repaint();
        }
    }

    private void updateTasksToggleButton() {
        if (tasksToggleButton != null) {
            tasksToggleButton.setText(tasksCollapsed ? "▶" : "◀");
            tasksToggleButton.setToolTipText(tasksCollapsed ? "Прошири секцију обавеза" : "Скупи секцију обавеза");
        }
        updateTasksHeaderLayout();
    }

    private void toggleTasksPanel() {
        if (splitPane == null) {
            return;
        }
        int collapsedWidth = 150;
        int current = splitPane.getDividerLocation();
        if (tasksCollapsed || current <= collapsedWidth + 4) {
            int target = expandedDividerLocation > collapsedWidth ? expandedDividerLocation : Math.max(280, (int) Math.round(getWidth() * 0.27));
            animateSplitPaneTo(target);
        } else {
            expandedDividerLocation = current;
            animateSplitPaneTo(collapsedWidth);
        }
    }

    private void animateSplitPaneTo(final int target) {
        if (splitPane == null) {
            return;
        }
        if (splitPaneAnimationTimer != null && splitPaneAnimationTimer.isRunning()) {
            splitPaneAnimationTimer.stop();
        }

        final int start = splitPane.getDividerLocation();
        if (start == target) {
            tasksCollapsed = target <= 100;
            if (!tasksCollapsed) {
                expandedDividerLocation = target;
            }
            if (tasksPanel != null) {
                tasksPanel.resetAnimationState();
            }
            updateTasksToggleButton();
            return;
        }

        final boolean collapsing = target < start;
        final int distance = target - start;
        final long startNanos = System.nanoTime();
        final int durationMs = Math.max(320, Math.min(560, 220 + Math.abs(distance)));
        final int maxSlideOffset = 28;

        splitPaneAnimationTimer = new Timer(1000 / 60, null);
        splitPaneAnimationTimer.setCoalesce(true);
        splitPaneAnimationTimer.addActionListener(e -> {
            float t = (System.nanoTime() - startNanos) / (durationMs * 1000000f);
            if (t > 1f) {
                t = 1f;
            }
            float eased = easeInOutCubic(t);
            int value = start + Math.round(distance * eased);
            splitPane.setDividerLocation(value);
            if (tasksPanel != null) {
                float visualProgress = collapsing ? eased : (1f - eased);
                int slideOffset = -Math.round(maxSlideOffset * visualProgress);
                float alpha = 1f - (0.12f * visualProgress);
                tasksPanel.setAnimationState(slideOffset, alpha);
            }
            updateTasksHeaderLayout();
            if (t >= 1f) {
                splitPaneAnimationTimer.stop();
                splitPane.setDividerLocation(target);
                tasksCollapsed = target <= 100;
                if (!tasksCollapsed) {
                    expandedDividerLocation = target;
                }
                if (tasksPanel != null) {
                    tasksPanel.resetAnimationState();
                }
                updateTasksToggleButton();
                SwingUtilities.invokeLater(() -> reflowSubjectsNow());
            }
        });
        splitPaneAnimationTimer.start();
    }

    private float easeInOutCubic(float t) {
        if (t <= 0f) {
            return 0f;
        }
        if (t >= 1f) {
            return 1f;
        }
        if (t < 0.5f) {
            return 4f * t * t * t;
        }
        float inv = -2f * t + 2f;
        return 1f - (inv * inv * inv) / 2f;
    }

    private void refreshStatusBar() {
        List<Subject> subjects = DataManager.getInstance().getSubjects(currentUser.getId());
        double average = 0.0;
        int gradedCount = 0;
        int ectsPassed = 0;
        int i;
        for (i = 0; i < subjects.size(); i++) {
            Subject subject = subjects.get(i);
            if (subject.getStatus() == SubjectStatus.PASSED) {
                ectsPassed += subject.getEcts();
                if (subject.getGrade() > 0.0) {
                    average += subject.getGrade();
                    gradedCount++;
                }
            }
        }
        average = gradedCount == 0 ? 0.0 : average / gradedCount;
        statsStatusLabel.setText(String.format(Locale.US, "Просек оцена: %.2f | ЕСПБ положено: %d", average, ectsPassed));
    }

    private void handleProfile() {
        JDialog dialog = new JDialog(this, "Профил", true);
        dialog.setSize(380, 460);
        dialog.setLocationRelativeTo(this);

        List<Subject> subjects = DataManager.getInstance().getSubjects(currentUser.getId());
        List<Task> tasks = DataManager.getInstance().getTasks(currentUser.getId());
        int passed = 0;
        int inProgress = 0;
        int failed = 0;
        int ectsPassed = 0;
        int ectsTotal = 0;
        double avg = 0.0;
        int avgCount = 0;
        int i;
        for (i = 0; i < subjects.size(); i++) {
            Subject subject = subjects.get(i);
            ectsTotal += subject.getEcts();
            if (subject.getStatus() == SubjectStatus.PASSED) {
                passed++;
                ectsPassed += subject.getEcts();
                if (subject.getGrade() > 0.0) {
                    avg += subject.getGrade();
                    avgCount++;
                }
            } else if (subject.getStatus() == SubjectStatus.FAILED) {
                failed++;
            } else {
                inProgress++;
            }
        }
        avg = avgCount == 0 ? 0.0 : avg / avgCount;

        Theme.BackgroundPanel bgPanel = new Theme.BackgroundPanel(new BorderLayout());
        dialog.setContentPane(bgPanel);
        installEscapeToClose(dialog);

        JPanel root = new JPanel();
        root.setOpaque(false);
        root.setLayout(new BoxLayout(root, BoxLayout.Y_AXIS));
        root.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        ImageIcon icon = Main.scaledLogoIcon(52);
        if (icon != null) {
            JLabel logo = new JLabel(icon);
            logo.setMinimumSize(new Dimension(52, 52));
            logo.setPreferredSize(new Dimension(52, 52));
            logo.setMaximumSize(new Dimension(52, 52));
            logo.setAlignmentX(Component.CENTER_ALIGNMENT);
            root.add(logo);
            root.add(Box.createVerticalStrut(8));
        }
        JLabel title = new JLabel("AtlasTM: Studije");
        title.setForeground(Theme.TEXT);
        title.setFont(Theme.fontBold(18));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        root.add(title);
        root.add(Box.createVerticalStrut(4));
        JLabel userLabel = Theme.mutedLabel(currentUser.getUsername());
        userLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        root.add(userLabel);
        root.add(Box.createVerticalStrut(10));
        root.add(separatorPanel());
        root.add(Box.createVerticalStrut(10));

        JPanel statsPanel = new JPanel(new GridLayout(0, 2, 8, 8));
        statsPanel.setOpaque(false);
        addStatLine(statsPanel, "Укупно предмета", String.valueOf(subjects.size()));
        addStatLine(statsPanel, "Положено", String.valueOf(passed));
        addStatLine(statsPanel, "У току", String.valueOf(inProgress));
        addStatLine(statsPanel, "Није положено", String.valueOf(failed));
        addStatLine(statsPanel, "Просек оцена", String.format(Locale.US, "%.2f", avg));
        addStatLine(statsPanel, "ЕСПБ", ectsPassed + " / " + ectsTotal);
        addStatLine(statsPanel, "Обавеза укупно", String.valueOf(tasks.size()));
        addStatLine(statsPanel, "Корисник", currentUser.getUsername());
        root.add(statsPanel);
        root.add(Box.createVerticalStrut(10));
        root.add(separatorPanel());
        root.add(Box.createVerticalStrut(10));

        JLabel aboutTitle = Theme.sectionTitle("О нама");
        aboutTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        root.add(aboutTitle);
        root.add(Box.createVerticalStrut(6));
        root.add(profileLine("Јован Касаловић"));
        root.add(profileLine("+381 645095965"));
        root.add(profileLine("kasalovicc.jovan@gmail.com"));
        root.add(profileLine("2026"));
        root.add(Box.createVerticalGlue());

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        footer.setOpaque(false);
        JButton closeButton = Theme.secondaryButton("Затвори");
        closeButton.addActionListener(e -> dialog.dispose());
        footer.add(closeButton);
        root.add(Box.createVerticalStrut(12));
        root.add(footer);

        bgPanel.add(root, BorderLayout.CENTER);
        dialog.setVisible(true);
    }

    private JLabel profileLine(String text) {
        JLabel label = Theme.mutedLabel(text);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        return label;
    }

    private void addStatLine(JPanel panel, String label, String value) {
        JLabel left = Theme.mutedLabel(label);
        JLabel right = new JLabel(value);
        right.setForeground(Theme.TEXT);
        right.setFont(Theme.fontBold(12));
        right.setHorizontalAlignment(SwingConstants.RIGHT);
        panel.add(left);
        panel.add(right);
    }

    private Component separatorPanel() {
        JPanel separator = gradientSeparator();
        separator.setAlignmentX(Component.LEFT_ALIGNMENT);
        separator.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        return separator;
    }

    private JPanel gradientSeparator() {
        JPanel gradSep = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(128, 183, 255, 0),
                        getWidth() * 0.15f, 0, new Color(128, 183, 255, 40)
                );
                g2.setPaint(gp);
                g2.fillRect(0, 0, (int) (getWidth() * 0.5f), 1);
                GradientPaint gp2 = new GradientPaint(
                        getWidth() * 0.5f, 0, new Color(128, 183, 255, 40),
                        getWidth(), 0, new Color(128, 183, 255, 0)
                );
                g2.setPaint(gp2);
                g2.fillRect((int) (getWidth() * 0.5f), 0, (int) (getWidth() * 0.5f), 1);
                g2.dispose();
            }
        };
        gradSep.setOpaque(false);
        gradSep.setPreferredSize(new Dimension(0, 1));
        return gradSep;
    }

    private void handleSettings() {
        JDialog dialog = new JDialog(this, "Подешавања", true);
        dialog.setMinimumSize(new Dimension(460, 360));
        dialog.setSize(460, 360);
        dialog.setResizable(false);
        Theme.BackgroundPanel bgPanel = new Theme.BackgroundPanel(new BorderLayout());
        bgPanel.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        dialog.setContentPane(bgPanel);
        installEscapeToClose(dialog);

        JPanel panel = Theme.surfaceCard();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(Theme.titledBorder("Промена лозинке"));

        JPasswordField currentField = Theme.passwordField("Тренутна лозинка");
        JPasswordField newField = Theme.passwordField("Нова лозинка");
        JPasswordField confirmField = Theme.passwordField("Потврди нову лозинку");
        currentField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        newField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        confirmField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

        panel.add(Theme.mutedLabel("Тренутна лозинка"));
        panel.add(Box.createVerticalStrut(6));
        panel.add(currentField);
        panel.add(Box.createVerticalStrut(10));
        panel.add(Theme.mutedLabel("Нова лозинка"));
        panel.add(Box.createVerticalStrut(6));
        panel.add(newField);
        panel.add(Box.createVerticalStrut(10));
        panel.add(Theme.mutedLabel("Потврди нову лозинку"));
        panel.add(Box.createVerticalStrut(6));
        panel.add(confirmField);

        JLabel error = Theme.errorLabel();
        error.setVisible(false);

        JPanel bottom = new JPanel();
        bottom.setOpaque(false);
        bottom.setLayout(new BoxLayout(bottom, BoxLayout.Y_AXIS));
        bottom.add(Box.createVerticalStrut(10));
        bottom.add(error);
        bottom.add(Box.createVerticalStrut(8));

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        footer.setOpaque(false);
        JButton confirmButton = Theme.primaryButton("Потврди");
        JButton cancelButton = Theme.secondaryButton("Откажи");
        footer.add(confirmButton);
        footer.add(cancelButton);
        bottom.add(footer);

        Runnable submitPasswordChange = new Runnable() {
            @Override
            public void run() {
                String current = new String(currentField.getPassword());
                String next = new String(newField.getPassword());
                String confirm = new String(confirmField.getPassword());
                User checkUser = new User();
                if (current.isEmpty() || next.isEmpty() || confirm.isEmpty()) {
                    error.setText("Сва поља су обавезна.");
                    error.setVisible(true);
                    dialog.pack();
                    return;
                }
                if (next.length() < 4) {
                    error.setText("Нова лозинка мора имати најмање 4 карактера.");
                    error.setVisible(true);
                    dialog.pack();
                    return;
                }
                if (!next.equals(confirm)) {
                    error.setText("Лозинке се не поклапају.");
                    error.setVisible(true);
                    dialog.pack();
                    return;
                }
                if (!DataManager.getInstance().loginUser(currentUser.getUsername(), current, checkUser)) {
                    error.setText("Тренутна лозинка није исправна.");
                    error.setVisible(true);
                    dialog.pack();
                    return;
                }
                if (!DataManager.getInstance().changePassword(currentUser.getId(), next)) {
                    error.setText("Лозинка није сачувана.");
                    error.setVisible(true);
                    dialog.pack();
                    return;
                }
                dialog.dispose();
            }
        };

        confirmButton.addActionListener(e -> submitPasswordChange.run());
        cancelButton.addActionListener(e -> dialog.dispose());
        dialog.getRootPane().setDefaultButton(confirmButton);

        bgPanel.add(panel, BorderLayout.CENTER);
        bgPanel.add(bottom, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setSize(Math.max(dialog.getWidth(), 460), Math.max(dialog.getHeight(), 360));
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void handleYearSemester() {
        JDialog dialog = new JDialog(this, "Година и семестар", true);
        dialog.setSize(420, 360);
        dialog.setLocationRelativeTo(this);
        Theme.BackgroundPanel bgPanel = new Theme.BackgroundPanel(new BorderLayout());
        dialog.setContentPane(bgPanel);
        installEscapeToClose(dialog);

        JPanel root = new JPanel();
        root.setOpaque(false);
        root.setOpaque(false);
        root.setLayout(new BoxLayout(root, BoxLayout.Y_AXIS));
        root.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        List<Subject> subjects = DataManager.getInstance().getSubjects(currentUser.getId());
        if (subjects.isEmpty()) {
            root.add(Theme.mutedLabel("Нема предмета."));
        } else {
            Map<String, int[]> stats = new LinkedHashMap<String, int[]>();
            int i;
            for (i = 0; i < subjects.size(); i++) {
                Subject subject = subjects.get(i);
                String key = subject.getYear() + "|" + subject.getSemester();
                if (!stats.containsKey(key)) {
                    stats.put(key, new int[] {0, 0});
                }
                stats.get(key)[0]++;
                if (subject.getStatus() == SubjectStatus.PASSED) {
                    stats.get(key)[1]++;
                }
            }
            for (Map.Entry<String, int[]> entry : stats.entrySet()) {
                String[] parts = entry.getKey().split("\\|");
                String label = parts[0] + ". год. / " + parts[1] + ". сем.:";
                String value = entry.getValue()[0] + " предмета, " + entry.getValue()[1] + " положено";
                JPanel row = new JPanel(new BorderLayout());
                row.setOpaque(false);
                JLabel left = Theme.mutedLabel(label);
                JLabel right = new JLabel(value);
                right.setForeground(Theme.TEXT);
                right.setFont(Theme.fontBold(12));
                row.add(left, BorderLayout.WEST);
                row.add(right, BorderLayout.EAST);
                root.add(row);
                root.add(Box.createVerticalStrut(8));
            }
        }

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        footer.setOpaque(false);
        JButton closeButton = Theme.secondaryButton("Затвори");
        closeButton.addActionListener(e -> dialog.dispose());
        footer.add(closeButton);

        bgPanel.add(root, BorderLayout.CENTER);
        bgPanel.add(footer, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void handleAddSubject() {
        openSubjectDialog(null);
    }

    private void handleAddTask() {
        openTaskDialog(null);
    }

    private void openSubjectDialog(Subject existing) {
        SubjectDialog dialog = new SubjectDialog(this, existing);
        dialog.setVisible(true);
        if (dialog.isSaved()) {
            Subject subject = dialog.getSubject();
            subject.setUserId(currentUser.getId());
            if (existing == null) {
                DataManager.getInstance().addSubject(subject);
            } else {
                DataManager.getInstance().updateSubject(subject);
            }
            refreshAll();
        }
    }

    private void openTaskDialog(Task existing) {
        TaskDialog dialog = new TaskDialog(this, existing);
        dialog.setVisible(true);
        if (dialog.isSaved()) {
            Task task = dialog.getTask();
            task.setUserId(currentUser.getId());
            if (existing == null) {
                DataManager.getInstance().addTask(task);
            } else {
                DataManager.getInstance().updateTask(task);
            }
            refreshAll();
        }
    }

    private void handleExit() {
        int result = JOptionPane.showConfirmDialog(this,
                "Да ли желите да завршите рад?\nСви подаци су аутоматски сачувани.",
                "Заврши рад",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);
        if (result == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

    private class TaskRenderer implements ListCellRenderer<Task> {
        @Override
        public Component getListCellRendererComponent(JList<? extends Task> list, Task task, int index, boolean isSelected, boolean cellHasFocus) {
            Theme.RoundedPanel root = new Theme.RoundedPanel(new BorderLayout());
            root.setBackground(isSelected ? new Color(17, 28, 45, 230) : new Color(10, 16, 28, 214));
            root.setBorder(BorderFactory.createCompoundBorder(
                    new Theme.RoundedBorder(isSelected ? Theme.BORDER_FOCUS : Theme.BORDER, 1, 6),
                    BorderFactory.createEmptyBorder(0, 0, 0, 0)
            ));

            Color accentColor;
            boolean overdue = !task.isCompleted() && task.getDate().isBefore(LocalDate.now());
            if (task.isCompleted()) {
                accentColor = Theme.MUTED;
            } else if (overdue) {
                accentColor = DANGER_TEXT;
            } else {
                accentColor = Theme.ACCENT;
            }

            JPanel accent = new JPanel();
            accent.setBackground(accentColor);
            accent.setPreferredSize(new Dimension(2, 68));
            root.add(accent, BorderLayout.WEST);

            JPanel content = new JPanel(new BorderLayout(10, 0));
            content.setOpaque(false);
            content.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

            StatusCheckMark checkMark = new StatusCheckMark(task.isCompleted());
            content.add(checkMark, BorderLayout.WEST);

            JPanel textPanel = new JPanel();
            textPanel.setOpaque(false);
            textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));

            JLabel titleLabel = createWrappedTitleLabel(
                    task.getTitle(),
                    230,
                    Theme.fontBold(11),
                    task.isCompleted() ? Theme.MUTED : Theme.TEXT,
                    task.isCompleted()
            );

            JLabel dateLabel = new JLabel();
            dateLabel.setFont(Theme.fontPlain(11));
            if (overdue) {
                dateLabel.setText("⚠ " + task.getDate().format(dateFormatter));
                dateLabel.setForeground(STATUS_RED);
            } else {
                dateLabel.setText(task.getDate().format(dateFormatter));
                dateLabel.setForeground(Theme.MUTED);
            }

            textPanel.add(titleLabel);
            textPanel.add(Box.createVerticalStrut(4));
            textPanel.add(dateLabel);
            content.add(textPanel, BorderLayout.CENTER);

            root.add(content, BorderLayout.CENTER);
            return root;
        }
    }

    private static class WrapFlowLayout extends FlowLayout {
        WrapFlowLayout(int align, int hgap, int vgap) {
            super(align, hgap, vgap);
        }

        @Override
        public Dimension preferredLayoutSize(Container target) {
            return layoutSize(target, true);
        }

        @Override
        public Dimension minimumLayoutSize(Container target) {
            Dimension minimum = layoutSize(target, false);
            minimum.width -= getHgap() + 1;
            return minimum;
        }

        private Dimension layoutSize(Container target, boolean preferred) {
            synchronized (target.getTreeLock()) {
                int targetWidth = target.getWidth();
                if (targetWidth <= 0) {
                    Container parent = target.getParent();
                    while (parent != null) {
                        targetWidth = parent.getWidth();
                        if (targetWidth > 0) {
                            break;
                        }
                        parent = parent.getParent();
                    }
                }

                if (targetWidth <= 0) {
                    targetWidth = Integer.MAX_VALUE;
                }

                Insets insets = target.getInsets();
                int horizontalInsetsAndGap = insets.left + insets.right + (getHgap() * 2);
                int maxWidth = targetWidth - horizontalInsetsAndGap;

                Dimension dim = new Dimension(0, 0);
                int rowWidth = 0;
                int rowHeight = 0;

                int count = target.getComponentCount();
                int i;
                for (i = 0; i < count; i++) {
                    Component component = target.getComponent(i);
                    if (!component.isVisible()) {
                        continue;
                    }

                    Dimension d = preferred ? component.getPreferredSize() : component.getMinimumSize();

                    if (rowWidth > 0 && rowWidth + getHgap() + d.width > maxWidth) {
                        addRow(dim, rowWidth, rowHeight);
                        rowWidth = 0;
                        rowHeight = 0;
                    }

                    if (rowWidth > 0) {
                        rowWidth += getHgap();
                    }
                    rowWidth += d.width;
                    rowHeight = Math.max(rowHeight, d.height);
                }

                addRow(dim, rowWidth, rowHeight);

                dim.width += horizontalInsetsAndGap;
                dim.height += insets.top + insets.bottom + getVgap() * 2;

                Container scrollPane = target.getParent();
                if (scrollPane instanceof javax.swing.JViewport) {
                    dim.width -= getHgap() + 1;
                }

                return dim;
            }
        }

        private void addRow(Dimension dim, int rowWidth, int rowHeight) {
            dim.width = Math.max(dim.width, rowWidth);
            if (dim.height > 0) {
                dim.height += getVgap();
            }
            dim.height += rowHeight;
        }
    }


    private static final class SlideFadePanel extends JPanel {
        private int slideOffsetX;
        private float contentAlpha = 1f;

        private SlideFadePanel(LayoutManager layout) {
            super(layout);
        }

        private void setAnimationState(int slideOffsetX, float contentAlpha) {
            float clampedAlpha = Math.max(0f, Math.min(1f, contentAlpha));
            if (this.slideOffsetX == slideOffsetX && Math.abs(this.contentAlpha - clampedAlpha) < 0.001f) {
                return;
            }
            this.slideOffsetX = slideOffsetX;
            this.contentAlpha = clampedAlpha;
            repaint();
        }

        private void resetAnimationState() {
            setAnimationState(0, 1f);
        }

        @Override
        protected void paintChildren(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.translate(slideOffsetX, 0);
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, contentAlpha));
            super.paintChildren(g2);
            g2.dispose();
        }
    }

    private static class StatusCheckMark extends JPanel {
        private final boolean checked;

        private StatusCheckMark(boolean checked) {
            this.checked = checked;
            setOpaque(false);
            setPreferredSize(new Dimension(18, 18));
            setMinimumSize(new Dimension(18, 18));
            setMaximumSize(new Dimension(18, 18));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int size = 14;
            int x = 2;
            int y = 2;
            if (checked) {
                g2.setColor(Theme.GOLD);
                g2.fillRoundRect(x, y, size, size, 4, 4);
            }
            g2.setColor(Theme.BORDER);
            g2.setStroke(new BasicStroke(1f));
            g2.drawRoundRect(x, y, size, size, 4, 4);
            if (checked) {
                g2.setColor(Theme.BG_DEEP);
                g2.setFont(Theme.fontBold(11));
                g2.drawString("✓", 4, 14);
            }
            g2.dispose();
            super.paintComponent(g);
        }
    }

    private String escapeHtml(String text) {
        if (text == null) {
            return "";
        }
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
