package atlas.studije.ui;

import atlas.studije.model.Subject;
import atlas.studije.model.SubjectStatus;
import atlas.studije.util.Theme;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.text.JTextComponent;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SubjectDialog extends JDialog {
    private final JTextField nameField;
    private final JSpinner yearSpinner;
    private final JComboBox<String> semesterComboBox;
    private final JSpinner ectsSpinner;
    private final JComboBox<String> gradeComboBox;
    private final JComboBox<SubjectStatus> statusComboBox;
    private final JTextArea notesArea;
    private final JLabel totalPointsLabel;
    private final JLabel errorLabel;
    private final DefaultTableModel tableModel;

    private boolean saved;
    private Subject subject;

    public SubjectDialog(JFrame owner, Subject initialSubject) {
        super(owner, initialSubject == null ? "Додај предмет" : "Измени предмет", true);
        this.subject = initialSubject == null ? new Subject() : initialSubject.copy();
        this.saved = false;

        setSize(520, 680);
        setMinimumSize(new Dimension(480, 600));
        setLocationRelativeTo(owner);
        setResizable(false);
        Theme.BackgroundPanel bgPanel = new Theme.BackgroundPanel(new BorderLayout());
        setContentPane(bgPanel);

        JPanel content = new JPanel();
        content.setOpaque(false);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(BorderFactory.createEmptyBorder(20, 24, 12, 24));

        JPanel basicsPanel = new JPanel();
        basicsPanel.setOpaque(false);
        basicsPanel.setLayout(new BoxLayout(basicsPanel, BoxLayout.Y_AXIS));
        basicsPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        nameField = Theme.inputField("нпр. Математика 1");
        yearSpinner = new JSpinner(new SpinnerNumberModel(this.subject.getYear() <= 0 ? 1 : this.subject.getYear(), 1, 7, 1));
        semesterComboBox = new JComboBox<String>(new String[] {"Зимски", "Летњи"});
        ectsSpinner = new JSpinner(new SpinnerNumberModel(this.subject.getEcts(), 0, 30, 1));
        gradeComboBox = new JComboBox<String>(new String[] {"Нема оцене", "6", "7", "8", "9", "10"});
        statusComboBox = new JComboBox<SubjectStatus>(SubjectStatus.values());
        Theme.applyComboBox(semesterComboBox);
        Theme.applyComboBox(gradeComboBox);
        Theme.applyComboBox(statusComboBox);
        nameField.setText(this.subject.getName());
        semesterComboBox.setSelectedIndex(this.subject.getSemester() == 2 ? 1 : 0);
        double currentGrade = this.subject.getGrade();
        if (currentGrade >= 6.0 && currentGrade <= 10.0) {
            gradeComboBox.setSelectedItem(String.valueOf((int) currentGrade));
        } else {
            gradeComboBox.setSelectedItem("Нема оцене");
        }
        statusComboBox.setSelectedItem(this.subject.getStatus() == null ? SubjectStatus.IN_PROGRESS : this.subject.getStatus());

        addFieldRow(basicsPanel, "Назив предмета", nameField);

        JPanel yearWrapper = Theme.styledSpinnerWrapper(yearSpinner);
        JPanel ectsWrapper = Theme.styledSpinnerWrapper(ectsSpinner);

        JPanel row1 = new JPanel(new GridLayout(1, 2, 12, 0));
        row1.setOpaque(false);
        row1.setAlignmentX(Component.CENTER_ALIGNMENT);
        row1.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));
        row1.add(labeledPanel("Година", yearWrapper));
        row1.add(labeledPanel("Семестар", semesterComboBox));
        basicsPanel.add(row1);
        basicsPanel.add(Box.createVerticalStrut(12));

        JPanel row2 = new JPanel(new GridLayout(1, 2, 12, 0));
        row2.setOpaque(false);
        row2.setAlignmentX(Component.CENTER_ALIGNMENT);
        row2.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));
        row2.add(labeledPanel("ЕСПБ бодови", ectsWrapper));
        row2.add(labeledPanel("Оцена", gradeComboBox));
        basicsPanel.add(row2);
        basicsPanel.add(Box.createVerticalStrut(12));

        addFieldRow(basicsPanel, "Статус", statusComboBox);

        gradeComboBox.addActionListener(e -> {
            Object selected = gradeComboBox.getSelectedItem();
            if (selected != null && !"Нема оцене".equals(String.valueOf(selected))) {
                statusComboBox.setSelectedItem(SubjectStatus.PASSED);
            }
        });

        JPanel pointsPanel = new JPanel(new BorderLayout(0, 8));
        pointsPanel.setOpaque(false);
        pointsPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        tableModel = new DefaultTableModel(new Object[] {"Начин освајања поена", "Бодови"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return true;
            }
        };
        JTable table = new JTable(tableModel);
        Theme.applyTable(table);
        table.setRowHeight(36);
        table.setGridColor(Theme.BORDER);
        table.getColumnModel().getColumn(1).setPreferredWidth(90);
        table.getColumnModel().getColumn(0).setCellEditor(createDescriptionEditor());
        table.getColumnModel().getColumn(1).setCellEditor(createPointsEditor());
        JTableHeader header = table.getTableHeader();
        header.setBackground(Theme.SURFACE);

        JScrollPane tableScroll = new JScrollPane(table);
        tableScroll.getViewport().setBackground(Theme.BG_CARD);
        tableScroll.setBackground(Theme.BG_CARD);
        tableScroll.setBorder(new Theme.RoundedBorder(Theme.BORDER, 1, 10));
        tableScroll.setPreferredSize(new Dimension(0, 160));
        Theme.applyScrollPane(tableScroll);
        tableScroll.setBorder(new Theme.RoundedBorder(Theme.BORDER, 1, 10));
        tableScroll.getViewport().setBackground(Theme.BG_CARD);
        pointsPanel.add(tableScroll, BorderLayout.CENTER);

        JPanel pointsFooter = new JPanel(new BorderLayout());
        pointsFooter.setOpaque(false);
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        buttons.setOpaque(false);
        JButton addPointButton = Theme.secondaryButton("+ Додај унос");
        addPointButton.setFont(Theme.fontPlain(12));
        addPointButton.setMargin(new Insets(4, 12, 4, 12));
        addPointButton.setPreferredSize(new Dimension(110, 32));
        JButton removePointButton = Theme.secondaryButton("− Уклони");
        removePointButton.setFont(Theme.fontPlain(12));
        removePointButton.setMargin(new Insets(4, 12, 4, 12));
        removePointButton.setPreferredSize(new Dimension(90, 32));
        buttons.add(addPointButton);
        buttons.add(removePointButton);
        pointsFooter.add(buttons, BorderLayout.WEST);
        totalPointsLabel = new JLabel();
        totalPointsLabel.setForeground(Theme.ACCENT);
        totalPointsLabel.setFont(Theme.fontBold(12));
        pointsFooter.add(totalPointsLabel, BorderLayout.EAST);
        pointsPanel.add(pointsFooter, BorderLayout.SOUTH);

        addPointButton.addActionListener(e -> {
            tableModel.addRow(new Object[] {"", "0"});
            int row = tableModel.getRowCount() - 1;
            updateTotalPoints();
            if (row >= 0) {
                table.requestFocusInWindow();
                table.changeSelection(row, 0, false, false);
                if (table.editCellAt(row, 0)) {
                    Component editor = table.getEditorComponent();
                    if (editor instanceof JTextComponent) {
                        ((JTextComponent) editor).requestFocusInWindow();
                        ((JTextComponent) editor).selectAll();
                    }
                }
            }
        });
        removePointButton.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                tableModel.removeRow(row);
                updateTotalPoints();
            }
        });
        tableModel.addTableModelListener(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {
                updateTotalPoints();
            }
        });

        JPanel notesPanel = new JPanel(new BorderLayout());
        notesPanel.setOpaque(false);
        notesPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        notesArea = Theme.textArea(3, "Додатне напомене о предмету...");
        notesArea.setRows(3);
        notesArea.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));
        notesArea.setText(this.subject.getNotes());
        JScrollPane notesScroll = new JScrollPane(notesArea);
        Theme.applyScrollPane(notesScroll);
        notesScroll.setBorder(new Theme.RoundedBorder(Theme.BORDER, 1, 10));
        notesScroll.getViewport().setBackground(new java.awt.Color(0, 0, 0, 0));
        notesPanel.add(notesScroll, BorderLayout.CENTER);

        errorLabel = Theme.errorLabel();
        errorLabel.setHorizontalAlignment(SwingConstants.LEFT);

        JButton saveButton = Theme.primaryButton(initialSubject == null ? "Додај предмет" : "Сачувај измене");
        saveButton.setPreferredSize(new Dimension(186, 40));

        JButton cancelButton = Theme.secondaryButton("Откажи");
        cancelButton.setPreferredSize(new Dimension(110, 40));

        saveButton.addActionListener(e -> saveSubject());
        cancelButton.addActionListener(e -> dispose());

        content.add(sectionHeader("Основне информације"));
        content.add(basicsPanel);
        content.add(Box.createVerticalStrut(20));
        content.add(sectionHeader("Поени"));
        content.add(pointsPanel);
        content.add(Box.createVerticalStrut(20));
        content.add(sectionHeader("Белешка"));
        content.add(notesPanel);
        content.add(Box.createVerticalStrut(12));

        JScrollPane rootScroll = new JScrollPane(content);
        Theme.applyScrollPane(rootScroll);
        bgPanel.add(rootScroll, BorderLayout.CENTER);
        bgPanel.add(createStickyActionBar(saveButton, cancelButton), BorderLayout.SOUTH);

        loadPointEntries();
        updateTotalPoints();
        installEscapeToClose();
    }

    private void installEscapeToClose() {
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_ESCAPE, 0), "atlas.closeDialog");
        getRootPane().getActionMap().put("atlas.closeDialog", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }

    private JPanel createStickyActionBar(JButton saveButton, JButton cancelButton) {
        JPanel holder = new JPanel(new BorderLayout());
        holder.setOpaque(false);
        holder.setBorder(BorderFactory.createEmptyBorder(8, 16, 14, 16));

        JPanel bar = Theme.surfaceCard(new BorderLayout(16, 0));
        bar.setBorder(BorderFactory.createCompoundBorder(
                new Theme.RoundedBorder(Theme.BORDER, 1, 14),
                BorderFactory.createEmptyBorder(10, 14, 10, 14)
        ));

        JPanel leftSide = new JPanel();
        leftSide.setOpaque(false);
        leftSide.setLayout(new BoxLayout(leftSide, BoxLayout.Y_AXIS));

        JLabel title = Theme.mutedLabel("Акције предмета");
        title.setFont(Theme.fontBold(12));
        leftSide.add(title);
        leftSide.add(Box.createVerticalStrut(4));
        leftSide.add(errorLabel);

        JPanel buttonGroup = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttonGroup.setOpaque(false);
        buttonGroup.add(cancelButton);
        buttonGroup.add(saveButton);

        bar.add(leftSide, BorderLayout.CENTER);
        bar.add(buttonGroup, BorderLayout.EAST);
        holder.add(bar, BorderLayout.CENTER);
        return holder;
    }

    private DefaultCellEditor createDescriptionEditor() {
        JTextField field = Theme.inputField();
        final DefaultCellEditor editor = new DefaultCellEditor(field);
        editor.setClickCountToStart(1);
        return editor;
    }

    private DefaultCellEditor createPointsEditor() {
        final JTextField field = Theme.inputField();
        field.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        field.selectAll();
                    }
                });
            }
        });
        DefaultCellEditor editor = new DefaultCellEditor(field) {
            @Override
            public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
                JTextField textField = (JTextField) super.getTableCellEditorComponent(table, value, isSelected, row, column);
                String text = value == null ? "0" : String.valueOf(value).trim();
                if (text.isEmpty()) {
                    text = "0";
                }
                textField.setText(text);
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        textField.requestFocusInWindow();
                        textField.selectAll();
                    }
                });
                return textField;
            }

            @Override
            public Object getCellEditorValue() {
                String text = field.getText() == null ? "" : field.getText().trim();
                return text.isEmpty() ? "0" : text.replace(',', '.');
            }
        };
        editor.setClickCountToStart(1);
        return editor;
    }

    private JLabel sectionHeader(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(Theme.TEXT);
        label.setFont(Theme.fontBold(14));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        label.setBorder(BorderFactory.createEmptyBorder(16, 0, 10, 0));
        return label;
    }

    private void addFieldRow(JPanel parent, String labelText, Component component) {
        JPanel panel = labeledPanel(labelText, component);
        panel.setAlignmentX(Component.CENTER_ALIGNMENT);
        parent.add(panel);
        parent.add(Box.createVerticalStrut(12));
    }

    private JPanel labeledPanel(String labelText, Component component) {
        JPanel panel = new JPanel();
        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel label = Theme.mutedLabel(labelText);
        label.setFont(Theme.fontPlain(12));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(label);
        panel.add(Box.createVerticalStrut(5));
        applyFieldSizing(component);
        panel.add(component);
        return panel;
    }

    private void applyFieldSizing(Component component) {
        if (component instanceof JTextField) {
            ((JTextField) component).setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
            ((JTextField) component).setPreferredSize(new Dimension(0, 42));
            ((JTextField) component).setAlignmentX(Component.CENTER_ALIGNMENT);
        }
        if (component instanceof JComboBox) {
            ((JComboBox<?>) component).setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
            ((JComboBox<?>) component).setPreferredSize(new Dimension(0, 42));
            ((JComboBox<?>) component).setAlignmentX(Component.CENTER_ALIGNMENT);
        }
        if (component instanceof JSpinner) {
            ((JSpinner) component).setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
            ((JSpinner) component).setPreferredSize(new Dimension(0, 42));
            ((JSpinner) component).setAlignmentX(Component.CENTER_ALIGNMENT);
        }
        if (component instanceof JPanel) {
            component.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
            component.setPreferredSize(new Dimension(0, 42));
            ((JPanel) component).setAlignmentX(Component.CENTER_ALIGNMENT);
        }
    }

    private void loadPointEntries() {
        List<Subject.PointEntry> entries = subject.getPointEntries();
        for (Subject.PointEntry entry : entries) {
            tableModel.addRow(new Object[] {entry.getDescription(), String.format(Locale.US, "%.2f", entry.getPoints())});
        }
    }

    private void updateTotalPoints() {
        double total = 0.0;
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            total += parseDouble(tableModel.getValueAt(i, 1));
        }
        totalPointsLabel.setText(String.format(Locale.US, "Укупно: %.2f поена", total));
    }

    private double parseDouble(Object value) {
        try {
            return value == null ? 0.0 : Double.parseDouble(String.valueOf(value).trim().replace(',', '.'));
        } catch (Exception ex) {
            return 0.0;
        }
    }

    private void saveSubject() {
        String name = nameField.getText().trim();
        if (name.isEmpty()) {
            errorLabel.setText("Назив предмета не сме бити празан.");
            errorLabel.setVisible(true);
            return;
        }
        List<Subject.PointEntry> entries = new ArrayList<Subject.PointEntry>();
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            String description = String.valueOf(tableModel.getValueAt(i, 0) == null ? "" : tableModel.getValueAt(i, 0)).trim();
            double points = parseDouble(tableModel.getValueAt(i, 1));
            if (!description.isEmpty() || Math.abs(points) > 0.0001) {
                entries.add(new Subject.PointEntry(description, points));
            }
        }
        subject.setName(name);
        subject.setYear(((Number) yearSpinner.getValue()).intValue());
        subject.setSemester(semesterComboBox.getSelectedIndex() + 1);
        subject.setEcts(((Number) ectsSpinner.getValue()).intValue());
        String selectedGrade = (String) gradeComboBox.getSelectedItem();
        subject.setGrade("Нема оцене".equals(selectedGrade) ? 0.0 : Double.parseDouble(selectedGrade));
        subject.setStatus((SubjectStatus) statusComboBox.getSelectedItem());
        subject.setNotes(notesArea.getText().trim());
        subject.setPointEntries(entries);
        saved = true;
        dispose();
    }

    public boolean isSaved() {
        return saved;
    }

    public Subject getSubject() {
        return subject == null ? null : subject.copy();
    }
}
