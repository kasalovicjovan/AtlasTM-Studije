package atlas.studije.ui;

import atlas.studije.DataManager;
import atlas.studije.Main;
import atlas.studije.model.User;
import atlas.studije.util.Theme;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class LoginFrame extends JFrame {
    private final JPanel cardPanel;
    private final JPanel loginPanel;
    private final JPanel registerPanel;

    private JTextField loginUsernameField;
    private JPasswordField loginPasswordField;
    private JLabel loginErrorLabel;

    private JTextField registerUsernameField;
    private JPasswordField registerPasswordField;
    private JPasswordField registerConfirmField;
    private JLabel registerErrorLabel;

    public LoginFrame() {
        super("AtlasTM: Studije");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(480, 620);
        setMinimumSize(new Dimension(480, 620));
        setMaximumSize(new Dimension(480, 620));
        setResizable(false);
        setLocationRelativeTo(null);
        Theme.applyWindow(this);
        Image icon = Main.loadLogo();
        if (icon != null) {
            setIconImage(icon);
        }

        JPanel root = new Theme.BackgroundPanel(new GridBagLayout());
        root.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));

        cardPanel = Theme.elevatedCard();
        cardPanel.setBackground(new java.awt.Color(17, 28, 45, 224));
        cardPanel.setLayout(new BorderLayout());
        cardPanel.setBorder(BorderFactory.createCompoundBorder(
                new Theme.RoundedBorder(Theme.BORDER_FOCUS, 1, 10),
                BorderFactory.createEmptyBorder(24, 28, 24, 28)
        ));

        loginPanel = buildLoginPanel();
        registerPanel = buildRegisterPanel();

        cardPanel.setMinimumSize(new Dimension(400, 520));
        cardPanel.setPreferredSize(new Dimension(400, 520));
        cardPanel.setMaximumSize(new Dimension(400, 520));
        cardPanel.add(loginPanel, BorderLayout.CENTER);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;
        root.add(cardPanel, gbc);

        setContentPane(root);
    }

    private JPanel buildLoginPanel() {
        JPanel panel = createFormPanel();
        addHeader(panel, "Пријавите се на ваш налог");

        loginUsernameField = Theme.inputField("Корисничко име");
        loginPasswordField = Theme.passwordField("Лозинка");
        loginErrorLabel = Theme.errorLabel();
        loginErrorLabel.setForeground(new java.awt.Color(0xE07070));

        addLabeledField(panel, "Корисничко име", loginUsernameField);
        addLabeledField(panel, "Лозинка", loginPasswordField);

        loginErrorLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        loginErrorLabel.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(loginErrorLabel);
        panel.add(Box.createVerticalStrut(14));

        JButton loginButton = Theme.primaryButton("Пријави се");
        loginButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        loginButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        loginButton.setPreferredSize(new Dimension(0, 42));
        loginButton.setFont(Theme.fontBold(14));
        loginButton.addActionListener(e -> doLogin());
        panel.add(loginButton);

        getRootPane().setDefaultButton(loginButton);

        panel.add(Box.createVerticalStrut(16));

        JButton switchButton = createLinkButton("Немате налог? Региструјте се");
        switchButton.addActionListener(e -> showRegister());
        panel.add(Box.createVerticalStrut(4));
        panel.add(switchButton);
        panel.add(Box.createVerticalStrut(62));
        panel.add(Box.createVerticalStrut(8));
        return panel;
    }

    private JPanel buildRegisterPanel() {
        JPanel panel = createFormPanel();
        addHeader(panel, "Направите нови локални налог");

        registerUsernameField = Theme.inputField("Корисничко име");
        registerPasswordField = Theme.passwordField("Лозинка");
        registerConfirmField = Theme.passwordField("Потврди лозинку");
        registerErrorLabel = Theme.errorLabel();
        registerErrorLabel.setForeground(new java.awt.Color(0xE07070));

        addLabeledField(panel, "Корисничко име", registerUsernameField);
        addLabeledField(panel, "Лозинка", registerPasswordField);
        addLabeledField(panel, "Потврди лозинку", registerConfirmField);

        registerErrorLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        registerErrorLabel.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(registerErrorLabel);
        panel.add(Box.createVerticalStrut(14));

        JButton registerButton = Theme.primaryButton("Региструј се");
        registerButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        registerButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        registerButton.setPreferredSize(new Dimension(0, 42));
        registerButton.setFont(Theme.fontBold(14));
        registerButton.addActionListener(e -> doRegister());
        panel.add(registerButton);

        panel.add(Box.createVerticalStrut(16));

        JButton switchButton = createLinkButton("Већ имате налог? Пријавите се");
        switchButton.addActionListener(e -> showLogin());
        panel.add(Box.createVerticalStrut(4));
        panel.add(switchButton);
        panel.add(Box.createVerticalStrut(8));
        return panel;
    }

    private JPanel createFormPanel() {
        JPanel panel = new JPanel();
        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        return panel;
    }

    private void addHeader(JPanel panel, String subtitleText) {
        ImageIcon icon = Main.scaledLogoIcon(52);
        if (icon != null) {
            JLabel logo = new JLabel(icon);
            logo.setMinimumSize(new Dimension(52, 52));
            logo.setPreferredSize(new Dimension(52, 52));
            logo.setMaximumSize(new Dimension(52, 52));
            logo.setAlignmentX(Component.CENTER_ALIGNMENT);
            panel.add(logo);
            panel.add(Box.createVerticalStrut(12));
        }

        JLabel title = new JLabel("Atlas™ Studije");
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setForeground(Theme.TEXT);
        title.setFont(Theme.brandFont(22));
        title.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(title);
        panel.add(Box.createVerticalStrut(10));

        JLabel subtitle = new JLabel(subtitleText);
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        subtitle.setForeground(Theme.TEXT);
        subtitle.setFont(Theme.fontBold(18));
        subtitle.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(subtitle);
        panel.add(Box.createVerticalStrut(24));
    }

    private void addLabeledField(JPanel panel, String labelText, Component field) {
        JLabel label = Theme.mutedLabel(labelText);
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(label);
        panel.add(Box.createVerticalStrut(4));
        if (field instanceof JTextField) {
            ((JTextField) field).setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
            ((JTextField) field).setAlignmentX(Component.CENTER_ALIGNMENT);
        }
        if (field instanceof JPasswordField) {
            ((JPasswordField) field).setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
            ((JPasswordField) field).setAlignmentX(Component.CENTER_ALIGNMENT);
        }
        panel.add(field);
        panel.add(Box.createVerticalStrut(12));
    }

    private JButton createLinkButton(final String text) {
        final JButton button = new JButton(text);
        button.setOpaque(false);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setForeground(Theme.ACCENT);
        button.setFont(Theme.fontPlain(13));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setHorizontalAlignment(SwingConstants.CENTER);
        button.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setText("<html><u>" + text + "</u></html>");
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setText(text);
            }
        });
        return button;
    }

    private void showLogin() {
        cardPanel.removeAll();
        cardPanel.add(loginPanel, BorderLayout.CENTER);
        cardPanel.revalidate();
        cardPanel.repaint();
        getRootPane().setDefaultButton(findPrimaryButton(loginPanel));
    }

    private void showRegister() {
        cardPanel.removeAll();
        cardPanel.add(registerPanel, BorderLayout.CENTER);
        cardPanel.revalidate();
        cardPanel.repaint();
        getRootPane().setDefaultButton(findPrimaryButton(registerPanel));
    }

    private JButton findPrimaryButton(JPanel panel) {
        Component[] components = panel.getComponents();
        int i;
        for (i = 0; i < components.length; i++) {
            if (components[i] instanceof JButton) {
                JButton button = (JButton) components[i];
                String txt = button.getText();
                if (txt != null && txt.indexOf("?") < 0) {
                    return button;
                }
            }
        }
        return null;
    }

    private void doLogin() {
        loginErrorLabel.setVisible(false);
        String username = loginUsernameField.getText().trim();
        String password = new String(loginPasswordField.getPassword());
        User user = new User();
        if (!DataManager.getInstance().loginUser(username, password, user)) {
            showError(loginErrorLabel, "Неисправно корисничко име или лозинка.");
            return;
        }
        openMainFrame(user);
    }

    private void doRegister() {
        registerErrorLabel.setVisible(false);
        String username = registerUsernameField.getText().trim();
        String password = new String(registerPasswordField.getPassword());
        String confirm = new String(registerConfirmField.getPassword());

        if (username.length() < 3) {
            showError(registerErrorLabel, "Корисничко име мора имати најмање 3 карактера.");
            return;
        }
        if (password.length() < 4) {
            showError(registerErrorLabel, "Лозинка мора имати најмање 4 карактера.");
            return;
        }
        if (!password.equals(confirm)) {
            showError(registerErrorLabel, "Лозинке се не поклапају.");
            return;
        }
        if (DataManager.getInstance().usernameExists(username)) {
            showError(registerErrorLabel, "Корисничко име већ постоји.");
            return;
        }
        if (!DataManager.getInstance().registerUser(username, password)) {
            showError(registerErrorLabel, "Регистрација није успела.");
            return;
        }
        User user = new User();
        if (!DataManager.getInstance().loginUser(username, password, user)) {
            showError(registerErrorLabel, "Налог је креиран, али пријава није успела.");
            return;
        }
        openMainFrame(user);
    }

    private void showError(JLabel label, String text) {
        label.setText(text);
        label.setVisible(true);
    }

    private void openMainFrame(User user) {
        setVisible(false);
        dispose();
        MainFrame mainFrame = new MainFrame(user);
        mainFrame.setVisible(true);
    }
}
