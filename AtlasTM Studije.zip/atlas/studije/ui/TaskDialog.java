package atlas.studije.ui;

import atlas.studije.model.Task;
import atlas.studije.util.Theme;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SpinnerDateModel;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

public class TaskDialog extends JDialog {
    private final JTextField titleField;
    private final JTextArea descriptionArea;
    private final JSpinner dateSpinner;
    private final JCheckBox completedCheckBox;
    private final JLabel errorLabel;

    private boolean saved;
    private Task task;

    public TaskDialog(JFrame owner, Task initialTask) {
        super(owner, initialTask == null ? "Нова обавеза" : "Измени обавезу", true);
        this.task = initialTask == null ? new Task() : initialTask.copy();
        this.saved = false;

        setSize(420, 430);
        setLocationRelativeTo(owner);
        setResizable(false);
        Theme.BackgroundPanel bgPanel = new Theme.BackgroundPanel(new BorderLayout());
        setContentPane(bgPanel);

        JPanel root = new JPanel();
        root.setOpaque(false);
        root.setOpaque(false);
        root.setLayout(new BoxLayout(root, BoxLayout.Y_AXIS));
        root.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JPanel detailsPanel = Theme.card();
        detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.Y_AXIS));
        detailsPanel.setBorder(Theme.titledBorder("Детаљи обавезе"));

        titleField = Theme.inputField("нпр. Предати домаћи из Анализе");
        titleField.setText(task.getTitle());
        titleField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

        descriptionArea = Theme.textArea(4, "Опис обавезе");
        descriptionArea.setText(task.getDescription());

        Date initialDate = Date.from(task.getDate().atStartOfDay(ZoneId.systemDefault()).toInstant());
        dateSpinner = new JSpinner(new SpinnerDateModel(initialDate, null, null, java.util.Calendar.DAY_OF_MONTH));
        Theme.applySpinner(dateSpinner);
        JSpinner.DateEditor editor = new JSpinner.DateEditor(dateSpinner, "dd.MM.yyyy");
        dateSpinner.setEditor(editor);
        editor.getTextField().setBackground(Theme.BG_CARD);
        editor.getTextField().setForeground(Theme.TEXT);
        editor.getTextField().setCaretColor(Theme.TEXT);
        dateSpinner.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

        completedCheckBox = new JCheckBox("Завршено");
        Theme.styleCheckBox(completedCheckBox);
        completedCheckBox.setSelected(task.isCompleted());

        detailsPanel.add(Theme.mutedLabel("Назив"));
        detailsPanel.add(Box.createVerticalStrut(6));
        detailsPanel.add(titleField);
        detailsPanel.add(Box.createVerticalStrut(12));
        detailsPanel.add(Theme.mutedLabel("Опис"));
        detailsPanel.add(Box.createVerticalStrut(6));
        JScrollPane descriptionScroll = new JScrollPane(descriptionArea);
        Theme.applyScrollPane(descriptionScroll);
        descriptionScroll.setBorder(new Theme.RoundedBorder(Theme.BORDER, 1, 10));
        descriptionScroll.getViewport().setBackground(new java.awt.Color(0, 0, 0, 0));
        descriptionScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        descriptionScroll.setPreferredSize(new Dimension(0, 110));
        detailsPanel.add(descriptionScroll);
        detailsPanel.add(Box.createVerticalStrut(12));
        detailsPanel.add(Theme.mutedLabel("Датум"));
        detailsPanel.add(Box.createVerticalStrut(6));
        detailsPanel.add(dateSpinner);
        detailsPanel.add(Box.createVerticalStrut(12));
        detailsPanel.add(completedCheckBox);

        errorLabel = Theme.errorLabel();
        errorLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        footer.setOpaque(false);
        JButton saveButton = Theme.primaryButton(initialTask == null ? "Додај обавезу" : "Сачувај");
        JButton cancelButton = Theme.secondaryButton("Откажи");
        saveButton.addActionListener(e -> saveTask());
        cancelButton.addActionListener(e -> dispose());
        footer.add(saveButton);
        footer.add(cancelButton);

        root.add(detailsPanel);
        root.add(Box.createVerticalStrut(10));
        root.add(errorLabel);
        root.add(Box.createVerticalStrut(8));
        root.add(footer);

        bgPanel.add(root, BorderLayout.CENTER);
        installEscapeToClose();
    }

    private void installEscapeToClose() {
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_ESCAPE, 0), "atlas.closeDialog");
        getRootPane().getActionMap().put("atlas.closeDialog", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }

    private void saveTask() {
        String title = titleField.getText().trim();
        if (title.isEmpty()) {
            errorLabel.setText("Назив обавезе не сме бити празан.");
            errorLabel.setVisible(true);
            return;
        }
        task.setTitle(title);
        task.setDescription(descriptionArea.getText().trim());
        Date value = (Date) dateSpinner.getValue();
        LocalDate date = Instant.ofEpochMilli(value.getTime()).atZone(ZoneId.systemDefault()).toLocalDate();
        task.setDate(date);
        task.setCompleted(completedCheckBox.isSelected());
        saved = true;
        dispose();
    }

    public boolean isSaved() {
        return saved;
    }

    public Task getTask() {
        return task == null ? null : task.copy();
    }
}
