@echo off
setlocal enabledelayedexpansion

set APP_JAR=%~dp0AtlasTMStudije.jar
set LOCAL_JRE=%~dp0runtime\bin\javaw.exe
set JAVA_EXE=

:: ============================================================
:: 1. Proveri da li postoji lokalni (portable) JRE u runtime\
:: ============================================================
if exist "%LOCAL_JRE%" (
    set JAVA_EXE="%LOCAL_JRE%"
    goto :run
)

:: ============================================================
:: 2. Proveri sistemski Java
:: ============================================================
where javaw >nul 2>&1
if not errorlevel 1 (
    set JAVA_EXE=javaw
    goto :run
)

if defined JAVA_HOME (
    if exist "%JAVA_HOME%\bin\javaw.exe" (
        set JAVA_EXE="%JAVA_HOME%\bin\javaw.exe"
        goto :run
    )
)

for /d %%d in ("C:\Program Files\Java\jdk*" "C:\Program Files\Java\jre*" "C:\Program Files\Java\latest") do (
    if exist "%%d\bin\javaw.exe" (
        set JAVA_EXE="%%d\bin\javaw.exe"
        goto :run
    )
)

:: ============================================================
:: 3. Java nije pronadjena - preuzmi portable JRE
:: ============================================================
echo Java nije pronadjena na ovom racunaru.
echo Preuzimam Java runtime (oko 180MB), sacekaj...
echo.

:: Temurin JRE 21 - Windows x64 zip
set JRE_URL=https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.6+7/OpenJDK21U-jre_x64_windows_hotspot_21.0.6_7.zip
set JRE_ZIP=%~dp0runtime.zip
set JRE_DIR=%~dp0runtime_temp

powershell -Command "& { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $ProgressPreference = 'SilentlyContinue'; Invoke-WebRequest -Uri '%JRE_URL%' -OutFile '%JRE_ZIP%'; }"

if not exist "%JRE_ZIP%" (
    echo GRESKA: Preuzimanje nije uspelo. Proveri internet konekciju.
    pause
    exit /b 1
)

echo Raspakujem...
powershell -Command "Expand-Archive -Path '%JRE_ZIP%' -DestinationPath '%JRE_DIR%' -Force"

:: Premesti sadrzaj u runtime\
for /d %%d in ("%JRE_DIR%\jdk*" "%JRE_DIR%\jre*") do (
    if exist "%%d\bin\javaw.exe" (
        move "%%d" "%~dp0runtime" >nul
        goto :cleanup
    )
)

:cleanup
rmdir /s /q "%JRE_DIR%" >nul 2>&1
del "%JRE_ZIP%" >nul 2>&1

if not exist "%LOCAL_JRE%" (
    echo GRESKA: Instalacija nije uspela.
    pause
    exit /b 1
)

echo Java uspesno preuzeta.
set JAVA_EXE="%LOCAL_JRE%"

:: ============================================================
:: 4. Pokreni aplikaciju
:: ============================================================
:run
if not exist "%APP_JAR%" (
    echo GRESKA: AtlasTMStudije.jar nije pronasao. Pokreni build.bat.
    pause
    exit /b 1
)

start "" %JAVA_EXE% -Dfile.encoding=UTF-8 -jar "%APP_JAR%"
